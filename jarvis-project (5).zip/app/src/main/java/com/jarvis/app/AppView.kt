package com.jarvis.app
import android.app.Activity
import android.os.Bundle
import android.webkit.WebView

class AppView : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val w = WebView(this); setContentView(w)
        w.settings.javaScriptEnabled = true; w.settings.domStorageEnabled = true; w.settings.allowFileAccess = true
        w.setBackgroundColor(0xFF02060D.toInt())
        w.loadUrl("file://" + intent.getStringExtra("p"))
    }
}
