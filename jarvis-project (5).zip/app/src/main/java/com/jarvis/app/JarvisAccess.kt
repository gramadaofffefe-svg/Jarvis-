package com.jarvis.app
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.io.ByteArrayOutputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class JarvisAccess : AccessibilityService() {
    companion object { var i: JarvisAccess? = null }
    val nodes = ArrayList<AccessibilityNodeInfo>()
    override fun onServiceConnected() { i = this }
    override fun onUnbind(x: Intent?): Boolean { i = null; return super.onUnbind(x) }
    var lastLog = 0L
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED || !Brain.pscreen()) return
        if (e.packageName?.toString() == packageName) return
        val now = System.currentTimeMillis(); if (now - lastLog < 4000) return; lastLog = now
        try {
            val t = dump(); val f = java.io.File(filesDir, "screen.txt")
            if (f.exists() && f.length() > 2000000) f.writeText(f.readText().takeLast(1000000))
            f.appendText("${java.text.SimpleDateFormat("dd/MM HH:mm", java.util.Locale.getDefault()).format(java.util.Date())} | ${t.replace("\n", " ").take(1200)}\n")
        } catch (x: Exception) {}
    }
    override fun onInterrupt() {}
    fun find(n: AccessibilityNodeInfo?, f: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        if (n == null) return null
        if (f(n)) return n
        for (k in 0 until n.childCount) find(n.getChild(k), f)?.let { return it }
        return null
    }
    fun dump(): String {
        nodes.clear()
        val r = rootInActiveWindow ?: return "(tela ilegível)"
        val sb = StringBuilder("app em primeiro plano: ${r.packageName}\n")
        walk(r, sb)
        return sb.toString().take(7000)
    }
    private fun walk(n: AccessibilityNodeInfo?, sb: StringBuilder) {
        if (n == null || nodes.size >= 130 || !n.isVisibleToUser || n.isPassword) return
        val t = (n.text ?: n.contentDescription)?.toString()?.replace("\n", " ")?.take(90) ?: ""
        if (t.isNotEmpty() || n.isClickable || n.isEditable) {
            nodes.add(n)
            val id = n.viewIdResourceName?.substringAfterLast('/') ?: ""
            sb.append("[${nodes.size - 1}] ${n.className?.toString()?.substringAfterLast('.')} \"$t\" ")
            if (n.isClickable) sb.append("clicável "); if (n.isEditable) sb.append("editável "); if (n.isScrollable) sb.append("rolável ")
            sb.append(id).append('\n')
        }
        for (k in 0 until n.childCount) walk(n.getChild(k), sb)
    }
    fun tapAt(x: Float, y: Float): Boolean {
        val p = Path().apply { moveTo(x, y) }
        return dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build(), null, null)
    }
    fun clickIdx(k: Int): String {
        val n0 = nodes.getOrNull(k) ?: return "índice $k inválido (releia a tela)"
        var n: AccessibilityNodeInfo? = n0
        while (n != null && !n.isClickable) n = n.parent
        if (n != null && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return "clicou"
        val r = Rect(); n0.getBoundsInScreen(r)
        return if (tapAt(r.exactCenterX(), r.exactCenterY())) "tocou na posição" else "falhou"
    }
    fun scroll(down: Boolean): String {
        val n = find(rootInActiveWindow) { it.isScrollable } ?: return "nada para rolar"
        n.performAction(if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
        return "rolou"
    }
    fun type(t: String): String {
        val root = rootInActiveWindow ?: return "sem tela"
        val n = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: find(root) { it.isEditable } ?: return "nenhum campo de texto"
        n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val b = Bundle(); b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t)
        return if (n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)) "digitado" else "falhou ao digitar"
    }
    fun enter(): String {
        val n = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return "sem campo focado"
        return if (Build.VERSION.SDK_INT >= 30 && n.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)) "enter enviado" else "enter falhou; clique no botão de buscar"
    }
    fun glob(a: Int): String { performGlobalAction(a); return "ok" }
    fun shot(): String? {
        if (Build.VERSION.SDK_INT < 30) return null
        val latch = CountDownLatch(1); var out: String? = null
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : AccessibilityService.TakeScreenshotCallback {
            override fun onSuccess(s: AccessibilityService.ScreenshotResult) {
                try {
                    val b = Bitmap.wrapHardwareBuffer(s.hardwareBuffer, s.colorSpace)!!.copy(Bitmap.Config.ARGB_8888, false)
                    s.hardwareBuffer.close()
                    val sc = Bitmap.createScaledBitmap(b, 540, (540f * b.height / b.width).toInt(), true)
                    val o = ByteArrayOutputStream(); sc.compress(Bitmap.CompressFormat.JPEG, 55, o)
                    out = Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
                } catch (e: Exception) {}
                latch.countDown()
            }
            override fun onFailure(c: Int) { latch.countDown() }
        })
        latch.await(4, TimeUnit.SECONDS)
        return out
    }
}
