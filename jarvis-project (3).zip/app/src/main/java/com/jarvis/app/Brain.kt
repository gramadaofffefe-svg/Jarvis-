package com.jarvis.app
import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaPlayer
import android.util.Base64
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.*

object Brain {
    lateinit var c: Context
    val h = Handler(Looper.getMainLooper())
    var tts: TextToSpeech? = null
    var ui: (String, String) -> Unit = { _, _ -> }
    var mode = "idle"
    var pulse = 0f
    val hist = ArrayList<Pair<String, String>>()
    var mp: MediaPlayer? = null
    var sr: SpeechRecognizer? = null
    @Volatile var cancel = false
    var track: AudioTrack? = null

    fun init(x: Context) {
        if (::c.isInitialized) return
        c = x
        tts = TextToSpeech(c) { st ->
            if (st == 0) {
                tts?.language = Locale("pt", "BR")
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(u: String?) { ev("mode", "speak"); h.post { pulser() } }
                    override fun onDone(u: String?) { ev("mode", "idle"); onSpeechEnd() }
                    override fun onError(u: String?) { ev("mode", "idle") }
                })
            }
        }
    }
    fun raw(): String = c.getSharedPreferences("j", 0).getString("cfg", "{}") ?: "{}"
    fun save(s: String) { c.getSharedPreferences("j", 0).edit().putString("cfg", s).apply() }
    fun cfg(): JSONObject = try { JSONObject(raw()) } catch (e: Exception) { JSONObject() }
    fun ev(m: String, t: String = "") {
        if (m == "mode") mode = t
        if (m == "pulse") pulse = t.toFloatOrNull() ?: 0.9f
        h.post { try { ui(m, t) } catch (e: Exception) {} }
    }
    fun voices(): String {
        val a = JSONArray()
        tts?.voices?.filter { it.locale.language == "pt" }?.sortedBy { it.name }?.forEach { a.put(it.name) }
        return a.toString()
    }
    fun pulser() {
        if (mode == "speak") { ev("pulse", (0.4f + Random().nextFloat() * 0.5f).toString()); h.postDelayed({ pulser() }, 130) }
    }
    fun stopSpeak() { cancel = true; try { sr?.cancel() } catch (e: Exception) {}; stopAudio() }
    fun stopAudio() {
        tts?.stop()
        try { mp?.release() } catch (e: Exception) {}
        try { track?.stop(); track?.release() } catch (e: Exception) {}
        mp = null; track = null; ev("mode", "idle")
    }
    fun onSpeechEnd() {
        if (!cancel && cfg().optBoolean("conv", false)) h.postDelayed({ if (!cancel && mode == "idle") listen { ask(it) } }, 500)
    }
    fun setCfg(k: String, v: Any) { val j = cfg(); j.put(k, v); save(j.toString()) }
    fun addMem(f: String) {
        val j = cfg(); if (!j.optBoolean("amem", true)) return
        val a = j.optJSONArray("mem") ?: JSONArray()
        for (i in 0 until a.length()) if (a.getString(i).equals(f, true)) return
        if (a.length() > 80) a.remove(0)
        a.put(f.take(160)); j.put("mem", a); save(j.toString())
    }
    fun mkTrack(n: Int, sr: Int, mode: Int): AudioTrack = AudioTrack.Builder()
        .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
        .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(sr).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
        .setBufferSizeInBytes(n).setTransferMode(mode).build()
    fun sfx(k: String) {
        if (!cfg().optBoolean("sfx", true)) return
        Thread {
            val sr = 22050
            val seq = when (k) {
                "on" -> listOf(520.0 to 70, 780.0 to 70, 1170.0 to 110)
                "think" -> listOf(660.0 to 50, 880.0 to 50)
                "done" -> listOf(880.0 to 70, 660.0 to 110)
                else -> listOf(1400.0 to 35)
            }
            val buf = ShortArray(sr * seq.sumOf { it.second } / 1000); var i = 0
            for ((f, ms) in seq) {
                val n = sr * ms / 1000
                for (x in 0 until n) { val env = Math.min(1.0, Math.min(x, n - x) / (sr * 0.01)); buf[i++] = (Math.sin(2 * Math.PI * f * x / sr) * env * 9000).toInt().toShort() }
            }
            try {
                val at = mkTrack(buf.size * 2, sr, AudioTrack.MODE_STATIC)
                at.write(buf, 0, buf.size); at.play()
                Thread.sleep(seq.sumOf { it.second } + 120L); at.release()
            } catch (e: Exception) {}
        }.start()
    }
    fun playPcm(b: ByteArray) {
        val at = mkTrack(b.size, 24000, AudioTrack.MODE_STATIC)
        at.write(b, 0, b.size); track = at
        at.setNotificationMarkerPosition(b.size / 2 - 1)
        at.setPlaybackPositionUpdateListener(object : AudioTrack.OnPlaybackPositionUpdateListener {
            override fun onMarkerReached(t: AudioTrack?) { ev("mode", "idle"); onSpeechEnd() }
            override fun onPeriodicNotification(t: AudioTrack?) {}
        })
        ev("mode", "speak"); h.post { pulser() }
        at.play()
    }
    fun gtts(t: String): Boolean {
        val j = cfg(); val voice = j.optString("gv"); if (voice.isEmpty()) return false
        var key = if (j.optString("prov", "gemini") == "gemini") j.optString("key") else ""
        if (key.isEmpty()) j.optJSONArray("provs")?.let { a -> for (i in 0 until a.length()) { val p = a.getJSONObject(i); if (p.optString("t") == "gemini" && key.isEmpty()) key = p.optString("k") } }
        if (key.isEmpty()) return false
        val model = j.optString("gvm").ifEmpty { "gemini-2.5-flash-preview-tts" }
        val txt = "Diga com voz grave, calma, elegante e levemente britânica, como uma IA sofisticada e leal: " + t.replace(Regex("[*_`#]"), "")
        val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", txt)))))
            .put("generationConfig", JSONObject().put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig", JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice)))))
        val o = JSONObject(String(post("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$key", body.toString()).second))
        if (o.has("error")) return false
        val d = o.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getJSONObject("inlineData").getString("data")
        playPcm(Base64.decode(d, Base64.DEFAULT)); return true
    }
    fun deep(t: String) {
        val j = cfg(); val tt = tts ?: return
        val vs = tt.voices?.filter { it.locale.language == "pt" } ?: listOf()
        val want = j.optString("voice")
        val v = vs.firstOrNull { it.name == want } ?: vs.firstOrNull {
            val n = it.name.lowercase(); (n.contains("ptd") || n.contains("pte") || n.contains("male")) && !n.contains("female")
        }
        if (v != null) tt.voice = v else tt.language = Locale("pt", "BR")
        tt.setPitch(j.optString("pitch", "0.6").toFloatOrNull() ?: 0.6f)
        tt.setSpeechRate(j.optString("rate", "0.92").toFloatOrNull() ?: 0.92f)
        tt.speak(t.replace(Regex("[*_`#]"), ""), TextToSpeech.QUEUE_FLUSH, null, "j")
    }
    fun speak(t: String) {
        stopAudio()
        val j = cfg(); val k = j.optString("vkey")
        if (k.isEmpty()) { Thread { if (!(try { gtts(t) } catch (e: Exception) { false })) h.post { deep(t) } }.start(); return }
        Thread {
            try {
                val id = j.optString("vid").ifEmpty { "pNInz6obpgDQGcFmaJgB" }
                val body = JSONObject().put("text", t.replace(Regex("[*_`#]"), "")).put("model_id", "eleven_multilingual_v2").toString()
                val (code, b) = post("https://api.elevenlabs.io/v1/text-to-speech/$id", body, mapOf("xi-api-key" to k))
                if (code < 300) {
                    val f = File(c.cacheDir, "v.mp3"); f.writeBytes(b)
                    h.post { play(f) }; return@Thread
                }
            } catch (e: Exception) {}
            h.post { deep(t) }
        }.start()
    }
    fun play(f: File) {
        try {
            val m = MediaPlayer(); mp = m
            m.setDataSource(f.path); m.prepare()
            m.setOnCompletionListener { ev("mode", "idle"); onSpeechEnd() }
            m.start(); ev("mode", "speak"); pulser()
        } catch (e: Exception) { ev("mode", "idle") }
    }
    fun listen(cb: (String) -> Unit) {
        h.post {
            try { sr?.destroy() } catch (e: Exception) {}
            tts?.stop()
            val s = SpeechRecognizer.createSpeechRecognizer(c); sr = s
            s.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(r: Float) { ev("pulse", ((r + 2f) / 12f).coerceIn(0f, 1f).toString()) }
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(e: Int) { ev("mode", "idle") }
                override fun onResults(r: Bundle?) {
                    val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (t.isNullOrEmpty()) ev("mode", "idle") else { ev("heard", t); cb(t) }
                }
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            sfx("on"); ev("mode", "listen")
            h.postDelayed({ s.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, "free_form").putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")) }, 350)
        }
    }
    fun post(u: String, body: String, hd: Map<String, String> = mapOf()): Pair<Int, ByteArray> {
        val k = URL(u).openConnection() as HttpURLConnection
        k.requestMethod = "POST"; k.doOutput = true; k.connectTimeout = 20000; k.readTimeout = 60000
        k.setRequestProperty("Content-Type", "application/json")
        hd.forEach { (a, b) -> k.setRequestProperty(a, b) }
        k.outputStream.use { it.write(body.toByteArray()) }
        val code = k.responseCode
        val s = if (code < 400) k.inputStream else k.errorStream
        return Pair(code, s.readBytes())
    }
    fun one(p: JSONObject, sys: String, user: String, img: String?): String {
        val key = p.optString("k")
        val model = p.optString("m").ifEmpty { "gemini-flash-latest" }
        if (p.optString("t", "gemini") == "gemini") {
            var err = ""
            for (m in listOf(model, "gemini-flash-latest")) {
                val parts = JSONArray().put(JSONObject().put("text", user))
                if (img != null) parts.put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", img)))
                val body = JSONObject()
                    .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
                    .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
                    .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
                val o = JSONObject(String(post("https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent?key=$key", body.toString()).second))
                if (!o.has("error")) return o.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
                err = o.getJSONObject("error").optString("message")
            }
            throw Exception(err)
        }
        val content: Any = if (img == null) user else JSONArray().put(JSONObject().put("type", "text").put("text", user))
            .put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$img")))
        val ms = JSONArray().put(JSONObject().put("role", "system").put("content", sys)).put(JSONObject().put("role", "user").put("content", content))
        val base = p.optString("b").ifEmpty { "https://api.openai.com/v1" }.trimEnd('/')
        val o = JSONObject(String(post("$base/chat/completions", JSONObject().put("model", model).put("messages", ms).toString(), mapOf("Authorization" to "Bearer $key")).second))
        if (o.has("error")) throw Exception(o.getJSONObject("error").optString("message"))
        return o.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
    }
    fun llm(sys: String, user: String, img: String?): String {
        val j = cfg(); val l = ArrayList<JSONObject>()
        if (j.optString("key").isNotEmpty()) l.add(JSONObject().put("n", "Principal").put("t", j.optString("prov", "gemini")).put("k", j.optString("key")).put("m", j.optString("model")).put("b", j.optString("base")))
        j.optJSONArray("provs")?.let { a -> for (i in 0 until a.length()) { val p = a.getJSONObject(i); if (p.optString("k").isNotEmpty()) l.add(p) } }
        if (l.isEmpty()) throw Exception("Configure uma API Key nas configurações.")
        var err = ""
        for (p in l) {
            try { return one(p, sys, user, img) } catch (e: Exception) {
                err = "${p.optString("n")}: ${e.message}"; ev("step", "⚠ ${p.optString("n", "IA")} falhou, passando para a próxima IA…")
            }
        }
        throw Exception(err)
    }
    fun appNames(): String {
        val pm = c.packageManager
        return pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.loadLabel(pm).toString() }.distinct().sorted().take(150).joinToString(", ")
    }
    fun agent(goal: String): String {
        val j = cfg()
        if (j.optString("key").isEmpty() && (j.optJSONArray("provs")?.length() ?: 0) == 0) return "Configure sua API Key nas configurações para eu ter cérebro."
        val mem = j.optJSONArray("mem")?.let { a -> (0 until a.length()).joinToString("; ") { a.getString(it) } } ?: ""
        val sys = "Você é ${j.optString("name", "Jarvis")}, assistente estilo Jarvis que controla o Android de ${j.optString("user").ifEmpty { "seu usuário" }}. " +
            "Personalidade: ${j.optString("pers")}. Memória do usuário: ${mem.ifEmpty { "nada ainda" }}. Agora: ${Date()}.\n" +
            "Responda SEMPRE apenas um JSON: {\"act\":\"...\",\"arg\":\"...\",\"say\":\"...\"}. Uma ação por vez. Ações: " +
            "open_app (arg=nome de um app instalado), click (arg=número [n] de um item da TELA ATUAL), type (arg=texto a digitar no campo de texto), " +
            "enter (confirma/pesquisa no teclado), scroll_down, scroll_up, back, home, wait, say (termina: fale em 'say', curto, natural para voz). " +
            "O usuário fala de forma natural e imprecisa: entenda a intenção e execute até concluir. Se for só conversa ou pergunta, use say direto. " +
            "Olhe a TELA ATUAL e as AÇÕES JÁ FEITAS; não repita o que falhou, tente outro caminho (ex.: ícone de busca, aba, botão). " +
            "Vídeo mais recente de um canal: pesquise o canal, abra-o, aba Vídeos (ordem recente) e abra o primeiro. " +
            "Se a acessibilidade estiver desligada, só consegue abrir apps: diga ao usuário para ativá-la. Ao concluir, use say confirmando. " +
            "Se aprender um fato durável sobre o usuário (nome, gostos, rotina, projetos, preferências), inclua também \"mem\":\"fato curto\" no JSON; nunca guarde senhas, dados bancários ou de saúde."
        val done = ArrayList<String>()
        for (n in 1..14) {
            if (cancel) return "Cancelado."
            val a = JarvisAccess.i
            val screen = a?.dump() ?: "(acessibilidade desligada: não vejo a tela)"
            val chat = hist.dropLast(1).takeLast(6).joinToString("\n") { "${it.first}: ${it.second}" }
            val user = "CONVERSA RECENTE:\n$chat\n\nPEDIDO: $goal\nAÇÕES JÁ FEITAS: ${done.joinToString(" | ").ifEmpty { "nenhuma" }}\n" +
                "APPS INSTALADOS: ${appNames()}\nTELA ATUAL:\n$screen"
            val vis = a != null && (screen.lines().size < 8 || Regex("tela|vê |ver |olha|imagem|foto|descreve").containsMatchIn(goal.lowercase()))
            val raw = try { llm(sys, user, if (vis) a?.shot() else null) } catch (e: Exception) { return "Falha: ${e.message}" }
            val o = try { JSONObject(raw.substring(raw.indexOf('{'), raw.lastIndexOf('}') + 1)) } catch (e: Exception) { return raw.take(300) }
            val act = o.optString("act"); val arg = o.optString("arg")
            o.optString("mem").takeIf { it.isNotBlank() }?.let { addMem(it) }
            if (act == "say" || act == "done") return o.optString("say").ifEmpty { arg }.ifEmpty { "Pronto." }
            ev("step", "$act $arg"); sfx("act")
            val res = when (act) {
                "open_app" -> openApp(arg) ?: "app não encontrado"
                "click" -> acc { it.clickIdx(arg.trim().toIntOrNull() ?: -1) }
                "type" -> acc { it.type(arg) }
                "enter" -> acc { it.enter() }
                "scroll_down" -> acc { it.scroll(true) }
                "scroll_up" -> acc { it.scroll(false) }
                "back" -> acc { it.glob(AccessibilityService.GLOBAL_ACTION_BACK) }
                "home" -> acc { it.glob(AccessibilityService.GLOBAL_ACTION_HOME) }
                "wait" -> "ok"
                else -> "ação desconhecida"
            }
            done.add("$act $arg -> $res")
            Thread.sleep(if (act == "open_app") 2800L else 1800L)
        }
        return "Fiz o que consegui, mas não consegui terminar. Me diga o próximo passo."
    }
    fun go(i: Intent) { c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    fun acc(f: (JarvisAccess) -> String): String = JarvisAccess.i?.let(f) ?: "Ative o controle de apps nas configurações do Jarvis."
    fun openApp(n0: String): String? {
        val n = n0.trim().lowercase().removePrefix("o ").removePrefix("a ").removePrefix("app ").removePrefix("aplicativo ")
        val pm = c.packageManager
        val ls = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val m = ls.map { it to it.loadLabel(pm).toString().lowercase() }
        val hit = m.firstOrNull { it.second == n } ?: m.firstOrNull { it.second.contains(n) } ?: m.firstOrNull { it.second.length > 2 && n.contains(it.second) }
        if (hit == null) return null
        val li = pm.getLaunchIntentForPackage(hit.first.activityInfo.packageName) ?: return null
        go(li)
        return "Abrindo ${hit.second}."
    }
    fun local(t: String): String? {
        val l = t.lowercase().trim().trimEnd('.', '!', '?')
        if (l.contains("modo conversa")) {
            val on = !Regex("desativ|desliga|sair|encerra").containsMatchIn(l); setCfg("conv", on)
            return if (on) "Modo conversa ativado. Vou continuar ouvindo." else "Modo conversa desativado."
        }
        Regex("^(?:jarvis,? )?(?:lembra|lembre|memorize|anote)(?: que| de)? (.+)").find(l)?.let {
            val j = cfg(); val a = j.optJSONArray("mem") ?: JSONArray()
            a.put(it.groupValues[1]); j.put("mem", a); save(j.toString()); return "Memorizado."
        }
        if (!Regex(" (e|depois|então|aí|pra|para|que) ").containsMatchIn(l))
            Regex("^(?:abr[ae]|abrir|inicia|iniciar|executa)(?: o| a)? (.+)").find(l)?.let { m -> openApp(m.groupValues[1])?.let { return it } }
        if (Regex("^(?:volta|voltar)$").matches(l)) return acc { it.glob(AccessibilityService.GLOBAL_ACTION_BACK) }
        if (Regex("^(?:início|inicio|home|tela inicial)$").matches(l)) return acc { it.glob(AccessibilityService.GLOBAL_ACTION_HOME) }
        if (l == "recentes") return acc { it.glob(AccessibilityService.GLOBAL_ACTION_RECENTS) }
        if (Regex("que horas").containsMatchIn(l)) return "Agora são " + java.text.SimpleDateFormat("HH:mm", Locale("pt", "BR")).format(Date()) + "."
        return null
    }
    fun ask(t: String) {
        cancel = false
        sfx("think"); ev("mode", "think")
        Thread {
            hist.add("user" to t)
            val r = try { local(t) ?: agent(t) } catch (e: Exception) { "Falha: ${e.message}" }
            hist.add("model" to r)
            while (hist.size > 24) hist.removeAt(0)
            ev("reply", r); sfx("done")
            h.postDelayed({ speak(r) }, 250)
        }.start()
    }
}
