package com.jarvis.app
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotifService : NotificationListenerService() {
    companion object { val recent = ArrayList<String>() }
    override fun onNotificationPosted(s: StatusBarNotification) {
        val e = s.notification.extras
        val t = e.getCharSequence("android.title")?.toString() ?: ""
        val x = e.getCharSequence("android.text")?.toString() ?: ""
        if (s.packageName == packageName || (t.isEmpty() && x.isEmpty())) return
        val app = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(s.packageName, 0)).toString() } catch (e: Exception) { s.packageName }
        synchronized(recent) { recent.add("[$app] $t: ${x.take(200)}"); while (recent.size > 40) recent.removeAt(0) }
    }
}
