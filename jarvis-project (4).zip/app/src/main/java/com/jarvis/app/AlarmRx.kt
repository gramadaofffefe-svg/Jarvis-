package com.jarvis.app
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmRx : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Brain.init(c.applicationContext)
        if (i.action == Intent.ACTION_BOOT_COMPLETED) Brain.rescheduleAll()
        else Brain.fire(i.getStringExtra("id") ?: return)
    }
}
