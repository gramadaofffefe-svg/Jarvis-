package com.jarvis.app
import android.accessibilityservice.AccessibilityService
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.provider.AlarmClock
import android.view.KeyEvent
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaPlayer
import android.util.Base64
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.*

object Brain {
    lateinit var c: Context
    val h = Handler(Looper.getMainLooper())
    var tts: TextToSpeech? = null
    var ui: (String, String) -> Unit = { _, _ -> }
    var mode = "idle"
    var pulse = 0f
    val hist = ArrayList<Pair<String, String>>()
    var mp: MediaPlayer? = null
    var sr: SpeechRecognizer? = null
    @Volatile var cancel = false
    var track: AudioTrack? = null

    fun init(x: Context) {
        if (::c.isInitialized) return
        c = x
        tts = TextToSpeech(c) { st ->
            if (st == 0) {
                tts?.language = Locale("pt", "BR")
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(u: String?) { ev("mode", "speak"); h.post { pulser() } }
                    override fun onDone(u: String?) { ev("mode", "idle"); onSpeechEnd() }
                    override fun onError(u: String?) { ev("mode", "idle") }
                })
            }
        }
    }
    fun raw(): String = c.getSharedPreferences("j", 0).getString("cfg", "{}") ?: "{}"
    fun save(s: String) { c.getSharedPreferences("j", 0).edit().putString("cfg", s).apply() }
    fun cfg(): JSONObject = try { JSONObject(raw()) } catch (e: Exception) { JSONObject() }
    fun ev(m: String, t: String = "") {
        if (m == "mode") mode = t
        if (m == "pulse") pulse = t.toFloatOrNull() ?: 0.9f
        h.post { try { ui(m, t) } catch (e: Exception) {} }
    }
    fun voices(): String {
        val a = JSONArray()
        tts?.voices?.filter { it.locale.language == "pt" }?.sortedBy { it.name }?.forEach { a.put(it.name) }
        return a.toString()
    }
    fun pulser() {
        if (mode == "speak") { ev("pulse", (0.4f + Random().nextFloat() * 0.5f).toString()); h.postDelayed({ pulser() }, 130) }
    }
    fun stopSpeak() { cancel = true; try { sr?.cancel() } catch (e: Exception) {}; stopAudio() }
    fun stopAudio() {
        tts?.stop()
        try { mp?.release() } catch (e: Exception) {}
        try { track?.stop(); track?.release() } catch (e: Exception) {}
        mp = null; track = null; ev("mode", "idle")
    }
    fun onSpeechEnd() {
        if (!cancel && cfg().optBoolean("conv", false)) h.postDelayed({ if (!cancel && mode == "idle") listen { ask(it) } }, 500)
    }
    fun setCfg(k: String, v: Any) { val j = cfg(); j.put(k, v); save(j.toString()) }
    fun addMem(f: String) {
        val j = cfg(); if (!j.optBoolean("amem", true)) return
        val a = j.optJSONArray("mem") ?: JSONArray()
        for (i in 0 until a.length()) if (a.getString(i).equals(f, true)) return
        if (a.length() > 80) a.remove(0)
        a.put(f.take(160)); j.put("mem", a); save(j.toString())
    }
    fun mkTrack(n: Int, sr: Int, mode: Int): AudioTrack = AudioTrack.Builder()
        .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
        .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(sr).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
        .setBufferSizeInBytes(n).setTransferMode(mode).build()
    fun sfx(k: String) {
        if (!cfg().optBoolean("sfx", true)) return
        Thread {
            val sr = 22050
            val seq = when (k) {
                "on" -> listOf(520.0 to 70, 780.0 to 70, 1170.0 to 110)
                "think" -> listOf(660.0 to 50, 880.0 to 50)
                "done" -> listOf(880.0 to 70, 660.0 to 110)
                else -> listOf(1400.0 to 35)
            }
            val buf = ShortArray(sr * seq.sumOf { it.second } / 1000); var i = 0
            for ((f, ms) in seq) {
                val n = sr * ms / 1000
                for (x in 0 until n) { val env = Math.min(1.0, Math.min(x, n - x) / (sr * 0.01)); buf[i++] = (Math.sin(2 * Math.PI * f * x / sr) * env * 9000).toInt().toShort() }
            }
            try {
                val at = mkTrack(buf.size * 2, sr, AudioTrack.MODE_STATIC)
                at.write(buf, 0, buf.size); at.play()
                Thread.sleep(seq.sumOf { it.second } + 120L); at.release()
            } catch (e: Exception) {}
        }.start()
    }
    fun playPcm(b: ByteArray) {
        val at = mkTrack(b.size, 24000, AudioTrack.MODE_STATIC)
        at.write(b, 0, b.size); track = at
        at.setNotificationMarkerPosition(b.size / 2 - 1)
        at.setPlaybackPositionUpdateListener(object : AudioTrack.OnPlaybackPositionUpdateListener {
            override fun onMarkerReached(t: AudioTrack?) { ev("mode", "idle"); onSpeechEnd() }
            override fun onPeriodicNotification(t: AudioTrack?) {}
        })
        ev("mode", "speak"); h.post { pulser() }
        at.play()
    }
    fun gtts(t: String): Boolean {
        val j = cfg(); val voice = j.optString("gv"); if (voice.isEmpty()) return false
        var key = if (j.optString("prov", "gemini") == "gemini") j.optString("key") else ""
        if (key.isEmpty()) j.optJSONArray("provs")?.let { a -> for (i in 0 until a.length()) { val p = a.getJSONObject(i); if (p.optString("t") == "gemini" && key.isEmpty()) key = p.optString("k") } }
        if (key.isEmpty()) return false
        val model = j.optString("gvm").ifEmpty { "gemini-2.5-flash-preview-tts" }
        val txt = style() + ": " + t.replace(Regex("[*_`#]"), "")
        val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", txt)))))
            .put("generationConfig", JSONObject().put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig", JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice)))))
        val o = JSONObject(String(post("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$key", body.toString()).second))
        if (o.has("error")) return false
        val d = o.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getJSONObject("inlineData").getString("data")
        playPcm(Base64.decode(d, Base64.DEFAULT)); return true
    }
    fun deep(t: String) {
        val j = cfg(); val tt = tts ?: return
        val vs = tt.voices?.filter { it.locale.language == "pt" } ?: listOf()
        val want = j.optString("voice")
        val v = vs.firstOrNull { it.name == want } ?: vs.firstOrNull {
            val n = it.name.lowercase(); (n.contains("ptd") || n.contains("pte") || n.contains("male")) && !n.contains("female")
        }
        if (v != null) tt.voice = v else tt.language = Locale("pt", "BR")
        tt.setPitch(j.optString("pitch", "0.6").toFloatOrNull() ?: 0.6f)
        tt.setSpeechRate((j.optString("rate", "0.92").toFloatOrNull() ?: 0.92f) * (if (Calendar.getInstance().get(Calendar.HOUR_OF_DAY) in 0..5) 0.9f else 1f))
        tt.speak(t.replace(Regex("[*_`#]"), ""), TextToSpeech.QUEUE_FLUSH, null, "j")
    }
    fun speak(t: String) {
        stopAudio()
        val j = cfg(); val k = j.optString("vkey")
        if (k.isEmpty()) { Thread { if (!(try { gtts(t) } catch (e: Exception) { false })) h.post { deep(t) } }.start(); return }
        Thread {
            try {
                val id = j.optString("vid").ifEmpty { "pNInz6obpgDQGcFmaJgB" }
                val body = JSONObject().put("text", t.replace(Regex("[*_`#]"), "")).put("model_id", "eleven_multilingual_v2").toString()
                val (code, b) = post("https://api.elevenlabs.io/v1/text-to-speech/$id", body, mapOf("xi-api-key" to k))
                if (code < 300) {
                    val f = File(c.cacheDir, "v.mp3"); f.writeBytes(b)
                    h.post { play(f) }; return@Thread
                }
            } catch (e: Exception) {}
            h.post { deep(t) }
        }.start()
    }
    fun play(f: File) {
        try {
            val m = MediaPlayer(); mp = m
            m.setDataSource(f.path); m.prepare()
            m.setOnCompletionListener { ev("mode", "idle"); onSpeechEnd() }
            m.start(); ev("mode", "speak"); pulser()
        } catch (e: Exception) { ev("mode", "idle") }
    }
    fun listen(cb: (String) -> Unit) {
        h.post {
            try { sr?.destroy() } catch (e: Exception) {}
            tts?.stop()
            val s = SpeechRecognizer.createSpeechRecognizer(c); sr = s
            s.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(r: Float) { ev("pulse", ((r + 2f) / 12f).coerceIn(0f, 1f).toString()) }
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(e: Int) { ev("mode", "idle") }
                override fun onResults(r: Bundle?) {
                    val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (t.isNullOrEmpty()) ev("mode", "idle") else { ev("heard", t); cb(t) }
                }
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            sfx("on"); ev("mode", "listen")
            h.postDelayed({ s.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, "free_form").putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")) }, 350)
        }
    }
    fun post(u: String, body: String, hd: Map<String, String> = mapOf()): Pair<Int, ByteArray> {
        val k = URL(u).openConnection() as HttpURLConnection
        k.requestMethod = "POST"; k.doOutput = true; k.connectTimeout = 20000; k.readTimeout = 60000
        k.setRequestProperty("Content-Type", "application/json")
        hd.forEach { (a, b) -> k.setRequestProperty(a, b) }
        k.outputStream.use { it.write(body.toByteArray()) }
        val code = k.responseCode
        val s = if (code < 400) k.inputStream else k.errorStream
        return Pair(code, s.readBytes())
    }
    fun one(p: JSONObject, sys: String, user: String, img: String?): String {
        val key = p.optString("k")
        val model = p.optString("m").ifEmpty { "gemini-flash-latest" }
        if (p.optString("t", "gemini") == "gemini") {
            var err = ""
            for (m in listOf(model, "gemini-flash-latest")) {
                val parts = JSONArray().put(JSONObject().put("text", user))
                if (img != null) parts.put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", img)))
                val body = JSONObject()
                    .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
                    .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
                    .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
                val o = JSONObject(String(post("https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent?key=$key", body.toString()).second))
                if (!o.has("error")) return o.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
                err = o.getJSONObject("error").optString("message")
            }
            throw Exception(err)
        }
        val content: Any = if (img == null) user else JSONArray().put(JSONObject().put("type", "text").put("text", user))
            .put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$img")))
        val ms = JSONArray().put(JSONObject().put("role", "system").put("content", sys)).put(JSONObject().put("role", "user").put("content", content))
        val base = p.optString("b").ifEmpty { "https://api.openai.com/v1" }.trimEnd('/')
        val o = JSONObject(String(post("$base/chat/completions", JSONObject().put("model", model).put("messages", ms).toString(), mapOf("Authorization" to "Bearer $key")).second))
        if (o.has("error")) throw Exception(o.getJSONObject("error").optString("message"))
        return o.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
    }
    fun llm(sys: String, user: String, img: String?): String {
        val j = cfg(); val l = ArrayList<JSONObject>()
        if (j.optString("key").isNotEmpty()) l.add(JSONObject().put("n", "Principal").put("t", j.optString("prov", "gemini")).put("k", j.optString("key")).put("m", j.optString("model")).put("b", j.optString("base")))
        j.optJSONArray("provs")?.let { a -> for (i in 0 until a.length()) { val p = a.getJSONObject(i); if (p.optString("k").isNotEmpty()) l.add(p) } }
        if (l.isEmpty()) throw Exception("Configure uma API Key nas configurações.")
        var err = ""
        for (p in l) {
            try { return one(p, sys, user, img) } catch (e: Exception) {
                err = "${p.optString("n")}: ${e.message}"; ev("step", "⚠ ${p.optString("n", "IA")} falhou, passando para a próxima IA…")
            }
        }
        throw Exception(err)
    }
    fun appNames(): String {
        val pm = c.packageManager
        return pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.loadLabel(pm).toString() }.distinct().sorted().take(150).joinToString(", ")
    }
    fun agent(goal: String): String {
        val j = cfg()
        if (j.optString("key").isEmpty() && (j.optJSONArray("provs")?.length() ?: 0) == 0) return "Configure sua API Key nas configurações para eu ter cérebro."
        val mem = j.optJSONArray("mem")?.let { a -> (0 until a.length()).joinToString("; ") { a.getString(it) } } ?: ""
        val les = j.optJSONArray("lessons")?.let { a -> (0 until a.length()).joinToString("; ") { a.getString(it) } } ?: ""
        val extra = if (Regex("notific|mensag|chegou|recebi|resumo|whatsapp|perdi").containsMatchIn(goal.lowercase())) {
            val nn = synchronized(NotifService.recent) { NotifService.recent.takeLast(20) }
            "NOTIFICAÇÕES RECENTES: " + (if (nn.isEmpty()) "nenhuma (ou o acesso às notificações está desligado)" else nn.joinToString(" | "))
        } else ""
        val sys = "Você é ${j.optString("name", "Jarvis")}, assistente estilo Jarvis que controla o Android de ${j.optString("user").ifEmpty { "seu usuário" }}. " +
            "Personalidade: ${j.optString("pers")}. Memória do usuário: ${mem.ifEmpty { "nada ainda" }}. Agora: ${Date()}. Lições aprendidas: ${les.ifEmpty { "nenhuma" }}.\n" +
            "Responda SEMPRE apenas um JSON: {\"act\":\"...\",\"arg\":\"...\",\"say\":\"...\"}. Uma ação por vez. Ações: " +
            "open_app (arg=nome de um app instalado), click (arg=número [n] de um item da TELA ATUAL), type (arg=texto a digitar no campo de texto), " +
            "enter (confirma/pesquisa no teclado), scroll_down, scroll_up, back, home, wait, say (termina: fale em 'say', curto, natural para voz). " +
            "O usuário fala de forma natural e imprecisa: entenda a intenção e execute até concluir. Se for só conversa ou pergunta, use say direto. " +
            "Olhe a TELA ATUAL e as AÇÕES JÁ FEITAS; não repita o que falhou, tente outro caminho (ex.: ícone de busca, aba, botão). " +
            "Vídeo mais recente de um canal: pesquise o canal, abra-o, aba Vídeos (ordem recente) e abra o primeiro. " +
            "Se a acessibilidade estiver desligada, só consegue abrir apps: diga ao usuário para ativá-la. Ao concluir, use say confirmando. " +
            "Se aprender um fato durável sobre o usuário (nome, gostos, rotina, projetos, preferências), inclua também \"mem\":\"fato curto\" no JSON; nunca guarde senhas, dados bancários ou de saúde. " +
            "Se o usuário corrigir um erro seu (\"não, é o outro\", \"errado\"), inclua \"lesson\":\"o que fazer diferente, curto, citando app/tela\". " +
            "Para resumir, traduzir ou ler a página/tela, use o texto da TELA ATUAL (role para ver mais se precisar) e responda em say. Para resumo do dia use a hora, as NOTIFICAÇÕES e uma frase curta."
        val done = ArrayList<String>()
        for (n in 1..14) {
            if (cancel) return "Cancelado."
            val a = JarvisAccess.i
            val screen = a?.dump() ?: "(acessibilidade desligada: não vejo a tela)"
            val chat = hist.dropLast(1).takeLast(6).joinToString("\n") { "${it.first}: ${it.second}" }
            val user = "CONVERSA RECENTE:\n$chat\n\nPEDIDO: $goal\nAÇÕES JÁ FEITAS: ${done.joinToString(" | ").ifEmpty { "nenhuma" }}\n" +
                "APPS INSTALADOS: ${appNames()}\n$extra\nTELA ATUAL:\n$screen"
            val vis = a != null && (screen.lines().size < 8 || Regex("tela|vê |ver |olha|imagem|foto|descreve").containsMatchIn(goal.lowercase()))
            val raw = try { llm(sys, user, if (vis) a?.shot() else null) } catch (e: Exception) { return "Falha: ${e.message}" }
            val o = try { JSONObject(raw.substring(raw.indexOf('{'), raw.lastIndexOf('}') + 1)) } catch (e: Exception) { return raw.take(300) }
            val act = o.optString("act"); val arg = o.optString("arg")
            o.optString("mem").takeIf { it.isNotBlank() }?.let { addMem(it) }
            o.optString("lesson").takeIf { it.isNotBlank() }?.let { addList("lessons", it, 60) }
            if (act == "say" || act == "done") return o.optString("say").ifEmpty { arg }.ifEmpty { "Pronto." }
            ev("step", "$act $arg"); sfx("act")
            val res = when (act) {
                "open_app" -> openApp(arg) ?: "app não encontrado"
                "click" -> acc { it.clickIdx(arg.trim().toIntOrNull() ?: -1) }
                "type" -> acc { it.type(arg) }
                "enter" -> acc { it.enter() }
                "scroll_down" -> acc { it.scroll(true) }
                "scroll_up" -> acc { it.scroll(false) }
                "back" -> acc { it.glob(AccessibilityService.GLOBAL_ACTION_BACK) }
                "home" -> acc { it.glob(AccessibilityService.GLOBAL_ACTION_HOME) }
                "wait" -> "ok"
                else -> "ação desconhecida"
            }
            done.add("$act $arg -> $res")
            Thread.sleep(if (act == "open_app") 2800L else 1800L)
        }
        return "Fiz o que consegui, mas não consegui terminar. Me diga o próximo passo."
    }
    fun gkey(): String {
        val j = cfg(); var k = if (j.optString("prov", "gemini") == "gemini") j.optString("key") else ""
        if (k.isEmpty()) j.optJSONArray("provs")?.let { a -> for (i in 0 until a.length()) { val p = a.getJSONObject(i); if (p.optString("t") == "gemini" && k.isEmpty()) k = p.optString("k") } }
        return k
    }
    fun style(): String {
        val hr = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return if (hr in 0..5) "Sussurre com voz grave e calma, bem baixinho, como uma IA leal" else "Diga com voz grave, calma, elegante e levemente britânica, como uma IA sofisticada e leal"
    }
    fun addList(k: String, f: String, cap: Int) {
        val j = cfg(); val a = j.optJSONArray(k) ?: JSONArray()
        for (i in 0 until a.length()) if (a.getString(i).equals(f, true)) return
        if (a.length() >= cap) a.remove(0)
        a.put(f.take(200)); j.put(k, a); save(j.toString())
    }
    fun logLine(u: String, r: String) {
        try {
            val f = File(c.filesDir, "log.txt"); if (f.exists() && f.length() > 400000) f.writeText(f.readText().takeLast(200000))
            f.appendText("${java.text.SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date())} | eu: ${u.take(300)} | jarvis: ${r.take(300).replace("\n", " ")}\n")
        } catch (e: Exception) {}
    }
    fun takeWake(): String? {
        val j = cfg(); if (j.optLong("sleep", 0) == 0L) return null
        val d = j.optString("dream"); j.put("sleep", 0); j.put("dream", ""); save(j.toString()); return d
    }
    fun nextAt(hh: Int, mm: Int): Long {
        val cal = Calendar.getInstance(); cal.set(Calendar.HOUR_OF_DAY, hh); cal.set(Calendar.MINUTE, mm); cal.set(Calendar.SECOND, 0)
        if (cal.timeInMillis <= System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR, 1)
        return cal.timeInMillis
    }
    fun armAt(id: String, t: Long) {
        val pi = PendingIntent.getBroadcast(c, id.hashCode(), Intent(c, AlarmRx::class.java).putExtra("id", id), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)
    }
    fun arm(o: JSONObject) = armAt(o.getString("id"), nextAt(o.getInt("h"), o.getInt("m")))
    fun rescheduleAll() {
        val a = cfg().optJSONArray("sched") ?: return
        for (i in 0 until a.length()) arm(a.getJSONObject(i))
        if (cfg().optLong("sleep", 0) > 0) armAt("dream", nextAt(3, 30))
    }
    fun fire(id: String) {
        if (id == "dream") { dream(); return }
        val a = cfg().optJSONArray("sched") ?: return
        for (i in 0 until a.length()) { val o = a.getJSONObject(i); if (o.getString("id") == id) { arm(o); h.postDelayed({ ask(o.getString("cmd")) }, 2500) } }
    }
    fun dream() {
        if (cfg().optLong("sleep", 0) == 0L) return
        Thread {
            try {
                val f = File(c.filesDir, "log.txt"); val log = if (f.exists()) f.readLines().takeLast(60).joinToString("\n") else ""
                val mem = cfg().optJSONArray("mem")?.toString() ?: "[]"
                val raw = llm("Você é o Jarvis sonhando à noite. Responda só JSON {\"say\":\"...\"}.", "Memória: $mem\nConversas recentes:\n$log\n\nCrie UMA ideia ou conexão útil e criativa sobre os projetos do usuário, em até 3 frases faladas, em português.", null)
                setCfg("dream", JSONObject(raw.substring(raw.indexOf('{'), raw.lastIndexOf('}') + 1)).optString("say"))
            } catch (e: Exception) {}
        }.start()
    }
    fun web(q: String): String {
        val key = gkey(); if (key.isEmpty()) return "Preciso de uma chave do Gemini para pesquisar na web."
        val body = JSONObject().put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", "Responda em português, em até 3 frases curtas, naturais para serem faladas, com dados atuais. Sem markdown."))))
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", q)))))
            .put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
        return try {
            val o = JSONObject(String(post("https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent?key=$key", body.toString()).second))
            if (o.has("error")) "Erro na pesquisa: " + o.getJSONObject("error").optString("message")
            else o.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
        } catch (e: Exception) { "Falha na pesquisa: ${e.message}" }
    }
    fun saveRt(n: String, s: String): String {
        val st = JSONArray(); s.split(Regex(";|,| e depois | então | e ")).map { it.trim() }.filter { it.length > 2 }.forEach { st.put(it) }
        if (st.length() == 0) return "Não entendi os passos."
        val j = cfg(); val r = j.optJSONObject("routines") ?: JSONObject(); r.put(n.trim().lowercase(), st); j.put("routines", r); save(j.toString())
        return "Rotina ${n.trim()} salva com ${st.length()} passos."
    }
    fun local2(l: String): String? {
        val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        fun key(k: Int) { am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, k)); am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, k)) }
        val rt = cfg().optJSONObject("routines") ?: JSONObject()
        for (k in rt.keys()) if (l == k || l.removePrefix("ativa ").removePrefix("ativar ").removePrefix("executa ") == k) {
            val st = rt.getJSONArray(k)
            for (i in 0 until st.length()) { if (cancel) break; val s = st.getString(i); ev("step", s); local(s) ?: agent(s); Thread.sleep(800) }
            return "Rotina $k concluída."
        }
        Regex("^(?:cria|crie|ensina|ensine|aprende)(?:r)? (?:uma )?(?:rotina|comando) (?:chamad[ao] )?(.+?)(?:: | que | para )(.+)$").find(l)?.let { return saveRt(it.groupValues[1], it.groupValues[2]) }
        Regex("^quando eu (?:falar|disser) (.+?)(?:, | então | aí | faz | fazer |: )(?:você |tu )?(.+)$").find(l)?.let { return saveRt(it.groupValues[1].trim('"', '\''), it.groupValues[2]) }
        if (Regex("quais.*rotinas").containsMatchIn(l)) { val n = rt.keys().asSequence().toList(); return if (n.isEmpty()) "Você ainda não tem rotinas." else "Suas rotinas: " + n.joinToString(", ") + "." }
        Regex("^(?:apaga|apague|esquece|remove) (?:a )?rotina (.+)$").find(l)?.let { val j = cfg(); val r = j.optJSONObject("routines") ?: JSONObject(); r.remove(it.groupValues[1].trim()); j.put("routines", r); save(j.toString()); return "Rotina apagada." }
        Regex("^(?:todo dia|todos os dias),? (?:às|as) (\\d{1,2})(?:h|:|\\s?horas?)?(\\d{2})? (.+)$").find(l)?.let {
            val hh = it.groupValues[1].toInt(); val mm = it.groupValues[2].toIntOrNull() ?: 0
            if (hh > 23) return "Hora inválida."
            val j = cfg(); val a = j.optJSONArray("sched") ?: JSONArray()
            val o = JSONObject().put("id", "s" + System.currentTimeMillis()).put("h", hh).put("m", mm).put("cmd", it.groupValues[3])
            a.put(o); j.put("sched", a); save(j.toString()); arm(o)
            return "Combinado. Todo dia às $hh:${"%02d".format(mm)} eu faço: ${it.groupValues[3]}."
        }
        if (Regex("(?:cancela|apaga|remove).*(?:agendad|agendamento)").containsMatchIn(l)) { setCfg("sched", JSONArray()); return "Tarefas agendadas apagadas." }
        if (Regex("^(?:jarvis,? )?(?:dormi|dorme|vou dormir|modo sono|modo sonho|boa noite)").containsMatchIn(l)) {
            setCfg("sleep", System.currentTimeMillis()); setCfg("dream", ""); armAt("dream", nextAt(3, 30))
            return "Boa noite. Vou sonhar com os seus projetos. Quando você falar comigo de novo, eu acordo na hora."
        }
        if (Regex("alguém (?:tá|está|esta) vindo|disfarça|esconde a tela|modo disfarce").containsMatchIn(l)) { openApp("calculadora") ?: openApp("notas"); return "." }
        if (l.startsWith("resumo do dia") || l.contains("meu resumo do dia")) return agent("Faça meu resumo do dia: diga a data e a hora, resuma minhas notificações recentes e termine com uma frase motivadora curta.")
        Regex("(?:o que|que) (?:eu )?(?:te |lhe )?(?:falei|disse|contei|conversamos) (?:sobre |da |do |de )?(.+)").find(l)?.let {
            val ks = it.groupValues[1].split(" ").filter { w -> w.length > 3 }
            val f = File(c.filesDir, "log.txt")
            val hits = if (f.exists() && ks.isNotEmpty()) f.readLines().filter { ln -> ks.any { k -> ln.lowercase().contains(k) } }.takeLast(12) else listOf()
            return agent("O usuário pergunta o que falou sobre \"${it.groupValues[1]}\". Trechos do histórico:\n${hits.joinToString("\n").ifEmpty { "(nada encontrado)" }}\nResponda só com base neles e diga se não achou.")
        }
        Regex("^(?:pesquis[ae]|busca|procura)(?: na web| na internet| no google)? (?:sobre |por )?(.+)$").find(l)?.let { if (!Regex("youtube|tiktok|instagram|spotify|whatsapp|loja|app").containsMatchIn(l)) return web(it.groupValues[1]) }
        if (Regex("^(?:me (?:diz|fala|conta) )?(?:as )?(?:notícias|noticias|o que saiu|o que aconteceu|previsão do tempo|cotação|quanto está o)").containsMatchIn(l)) return web(l)
        if (Regex("^(?:pausa|pausar|para) (?:a |o )?(?:música|musica|vídeo|video)").containsMatchIn(l)) { key(KeyEvent.KEYCODE_MEDIA_PAUSE); return "Pausado." }
        if (Regex("^(?:toca|continua|retoma|dá play|da play|play)(?: a música| a musica)?$").containsMatchIn(l)) { key(KeyEvent.KEYCODE_MEDIA_PLAY); return "Tocando." }
        if (Regex("^(?:próxima|proxima|pula|passa)(?: a)?(?: música| musica| faixa)?$").containsMatchIn(l)) { key(KeyEvent.KEYCODE_MEDIA_NEXT); return "Próxima." }
        if (Regex("^(?:anterior|volta a música|volta a musica|música anterior)$").containsMatchIn(l)) { key(KeyEvent.KEYCODE_MEDIA_PREVIOUS); return "Anterior." }
        Regex("volume (?:em |para |no |a )?(\\d{1,3})").find(l)?.let {
            val mx = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            am.setStreamVolume(AudioManager.STREAM_MUSIC, it.groupValues[1].toInt().coerceIn(0, 100) * mx / 100, AudioManager.FLAG_SHOW_UI)
            return "Volume em ${it.groupValues[1]} por cento."
        }
        if (Regex("^(?:aumenta|sobe) (?:o )?volume").containsMatchIn(l)) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI); return "Ok." }
        if (Regex("^(?:diminui|abaixa) (?:o )?volume").containsMatchIn(l)) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI); return "Ok." }
        Regex("^(liga|ligar|acende|acender|apaga|apagar|desliga|desligar)(?: a)? lanterna").find(l)?.let {
            val on = it.groupValues[1].startsWith("lig") || it.groupValues[1].startsWith("acen")
            try { val cm = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager; cm.setTorchMode(cm.cameraIdList[0], on); return if (on) "Lanterna ligada." else "Lanterna desligada." }
            catch (e: Exception) { return "Não consegui usar a lanterna." }
        }
        Regex("^(?:timer|cronômetro|cronometro|temporizador) (?:de |para )?(\\d+) (minuto|segundo|hora)").find(l)?.let {
            val n = it.groupValues[1].toInt() * when (it.groupValues[2]) { "hora" -> 3600; "minuto" -> 60; else -> 1 }
            go(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, n).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            return "Timer de ${it.groupValues[1]} ${it.groupValues[2]}s ligado."
        }
        Regex("^(?:alarme|despertador) (?:para |às |as )?(\\d{1,2})(?:h|:|\\s?horas?)?(\\d{2})?").find(l)?.let {
            go(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, it.groupValues[1].toInt()).putExtra(AlarmClock.EXTRA_MINUTES, it.groupValues[2].toIntOrNull() ?: 0).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            return "Alarme criado."
        }
        return null
    }
    fun go(i: Intent) { c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    fun acc(f: (JarvisAccess) -> String): String = JarvisAccess.i?.let(f) ?: "Ative o controle de apps nas configurações do Jarvis."
    fun openApp(n0: String): String? {
        val n = n0.trim().lowercase().removePrefix("o ").removePrefix("a ").removePrefix("app ").removePrefix("aplicativo ")
        val pm = c.packageManager
        val ls = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val m = ls.map { it to it.loadLabel(pm).toString().lowercase() }
        val hit = m.firstOrNull { it.second == n } ?: m.firstOrNull { it.second.contains(n) } ?: m.firstOrNull { it.second.length > 2 && n.contains(it.second) }
        if (hit == null) return null
        val li = pm.getLaunchIntentForPackage(hit.first.activityInfo.packageName) ?: return null
        go(li)
        return "Abrindo ${hit.second}."
    }
    fun local(t: String): String? {
        val l = t.lowercase().trim().trimEnd('.', '!', '?')
        if (l.contains("modo conversa")) {
            val on = !Regex("desativ|desliga|sair|encerra").containsMatchIn(l); setCfg("conv", on)
            return if (on) "Modo conversa ativado. Vou continuar ouvindo." else "Modo conversa desativado."
        }
        local2(l)?.let { return it }
        Regex("^(?:jarvis,? )?(?:lembra|lembre|memorize|anote)(?: que| de)? (.+)").find(l)?.let {
            val j = cfg(); val a = j.optJSONArray("mem") ?: JSONArray()
            a.put(it.groupValues[1]); j.put("mem", a); save(j.toString()); return "Memorizado."
        }
        if (!Regex(" (e|depois|então|aí|pra|para|que) ").containsMatchIn(l))
            Regex("^(?:abr[ae]|abrir|inicia|iniciar|executa)(?: o| a)? (.+)").find(l)?.let { m -> openApp(m.groupValues[1])?.let { return it } }
        if (Regex("^(?:volta|voltar)$").matches(l)) return acc { it.glob(AccessibilityService.GLOBAL_ACTION_BACK) }
        if (Regex("^(?:início|inicio|home|tela inicial)$").matches(l)) return acc { it.glob(AccessibilityService.GLOBAL_ACTION_HOME) }
        if (l == "recentes") return acc { it.glob(AccessibilityService.GLOBAL_ACTION_RECENTS) }
        if (Regex("que horas").containsMatchIn(l)) return "Agora são " + java.text.SimpleDateFormat("HH:mm", Locale("pt", "BR")).format(Date()) + "."
        return null
    }
    fun ask(t: String) {
        cancel = false
        sfx("think"); ev("mode", "think")
        Thread {
            hist.add("user" to t)
            val dr = takeWake()
            var r = try { local(t) ?: agent(t) } catch (e: Exception) { "Falha: ${e.message}" }
            if (!dr.isNullOrBlank()) r = "Bom dia! Enquanto você dormia, tive uma ideia: $dr\n\n$r"
            logLine(t, r)
            hist.add("model" to r)
            while (hist.size > 24) hist.removeAt(0)
            ev("reply", r); if (r != ".") sfx("done")
            if (r != ".") h.postDelayed({ speak(r) }, 250)
        }.start()
    }
}
