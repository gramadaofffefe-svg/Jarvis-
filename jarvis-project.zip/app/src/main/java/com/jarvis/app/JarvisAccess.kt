package com.jarvis.app
import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class JarvisAccess : AccessibilityService() {
    companion object { var i: JarvisAccess? = null }
    override fun onServiceConnected() { i = this }
    override fun onUnbind(x: Intent?): Boolean { i = null; return super.onUnbind(x) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    fun find(n: AccessibilityNodeInfo?, f: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        if (n == null) return null
        if (f(n)) return n
        for (k in 0 until n.childCount) find(n.getChild(k), f)?.let { return it }
        return null
    }
    fun clickText(t: String): String {
        val r = rootInActiveWindow ?: return "Não consigo ler a tela."
        var n: AccessibilityNodeInfo? = r.findAccessibilityNodeInfosByText(t).firstOrNull() ?: return "Não achei $t na tela."
        while (n != null && !n.isClickable) n = n.parent
        return if (n?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true) "Cliquei em $t." else "Não consegui clicar em $t."
    }
    fun scroll(down: Boolean): String {
        val n = find(rootInActiveWindow) { it.isScrollable } ?: return "Nada para rolar."
        n.performAction(if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
        return "Ok."
    }
    fun type(t: String): String {
        val n = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return "Nenhum campo de texto selecionado."
        val b = Bundle(); b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t)
        n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
        return "Digitado."
    }
    fun glob(a: Int): String { performGlobalAction(a); return "Ok." }
}
