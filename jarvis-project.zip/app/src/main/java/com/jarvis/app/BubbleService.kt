package com.jarvis.app
import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.*
import android.os.Build
import android.os.IBinder
import android.view.*

class BubbleService : Service() {
    var v: View? = null
    lateinit var wm: WindowManager
    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        if (v != null) return START_STICKY
        Brain.init(applicationContext)
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("j", "Jarvis", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "j").setContentTitle("Jarvis ativo").setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) else startForeground(1, n)
        } catch (e: Exception) { stopSelf(); return START_NOT_STICKY }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val sz = (68 * resources.displayMetrics.density).toInt()
        val lp = WindowManager.LayoutParams(sz, sz, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START; lp.x = 20; lp.y = 400
        val view = object : View(this) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            var last = ""; var col = Color.CYAN
            override fun onDraw(c: Canvas) {
                if (last != Brain.mode) {
                    last = Brain.mode
                    col = try { Color.parseColor(Brain.cfg().optString(if (last == "listen" || last == "speak") last else "idle", "#18e0ff")) } catch (e: Exception) { Color.CYAN }
                }
                Brain.pulse *= 0.9f
                val cx = width / 2f; val r = cx - 6f
                p.color = col; p.style = Paint.Style.STROKE; p.strokeWidth = 4f
                for (k in 0..2) c.drawCircle(cx, cx, r * (0.45f + k * 0.28f) * (1f + Brain.pulse * 0.12f), p)
                p.style = Paint.Style.FILL
                c.drawCircle(cx, cx, r * 0.18f * (1f + Brain.pulse), p)
                postInvalidateOnAnimation()
            }
        }
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var moved = false
        view.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = lp.x; sy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (Math.abs(e.rawX - dx) + Math.abs(e.rawY - dy) > 15) moved = true
                    lp.x = sx + (e.rawX - dx).toInt(); lp.y = sy + (e.rawY - dy).toInt(); wm.updateViewLayout(view, lp)
                }
                MotionEvent.ACTION_UP -> if (!moved) {
                    if (Brain.mode == "idle" || Brain.mode == "think") Brain.listen { Brain.ask(it) } else Brain.stopSpeak()
                }
            }
            true
        }
        wm.addView(view, lp); v = view
        return START_STICKY
    }
    override fun onDestroy() { v?.let { wm.removeView(it) }; v = null; super.onDestroy() }
}
