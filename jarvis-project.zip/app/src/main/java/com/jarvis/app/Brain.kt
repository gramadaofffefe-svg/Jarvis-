package com.jarvis.app
import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.*

object Brain {
    lateinit var c: Context
    val h = Handler(Looper.getMainLooper())
    var tts: TextToSpeech? = null
    var ui: (String, String) -> Unit = { _, _ -> }
    var mode = "idle"
    var pulse = 0f
    val hist = ArrayList<Pair<String, String>>()
    var mp: MediaPlayer? = null
    var sr: SpeechRecognizer? = null

    fun init(x: Context) {
        if (::c.isInitialized) return
        c = x
        tts = TextToSpeech(c) { st ->
            if (st == 0) {
                tts?.language = Locale("pt", "BR")
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(u: String?) { ev("mode", "speak"); h.post { pulser() } }
                    override fun onDone(u: String?) { ev("mode", "idle") }
                    override fun onError(u: String?) { ev("mode", "idle") }
                })
            }
        }
    }
    fun raw(): String = c.getSharedPreferences("j", 0).getString("cfg", "{}") ?: "{}"
    fun save(s: String) { c.getSharedPreferences("j", 0).edit().putString("cfg", s).apply() }
    fun cfg(): JSONObject = try { JSONObject(raw()) } catch (e: Exception) { JSONObject() }
    fun ev(m: String, t: String = "") {
        if (m == "mode") mode = t
        if (m == "pulse") pulse = t.toFloatOrNull() ?: 0.9f
        h.post { try { ui(m, t) } catch (e: Exception) {} }
    }
    fun voices(): String {
        val a = JSONArray()
        tts?.voices?.filter { it.locale.language == "pt" }?.sortedBy { it.name }?.forEach { a.put(it.name) }
        return a.toString()
    }
    fun pulser() {
        if (mode == "speak") { ev("pulse", (0.4f + Random().nextFloat() * 0.5f).toString()); h.postDelayed({ pulser() }, 130) }
    }
    fun stopSpeak() {
        tts?.stop(); try { sr?.cancel() } catch (e: Exception) {}
        try { mp?.release() } catch (e: Exception) {}
        mp = null; ev("mode", "idle")
    }
    fun deep(t: String) {
        val j = cfg(); val tt = tts ?: return
        val vs = tt.voices?.filter { it.locale.language == "pt" } ?: listOf()
        val want = j.optString("voice")
        val v = vs.firstOrNull { it.name == want } ?: vs.firstOrNull {
            val n = it.name.lowercase(); (n.contains("ptd") || n.contains("pte") || n.contains("male")) && !n.contains("female")
        }
        if (v != null) tt.voice = v else tt.language = Locale("pt", "BR")
        tt.setPitch(j.optString("pitch", "0.6").toFloatOrNull() ?: 0.6f)
        tt.setSpeechRate(j.optString("rate", "0.92").toFloatOrNull() ?: 0.92f)
        tt.speak(t.replace(Regex("[*_`#]"), ""), TextToSpeech.QUEUE_FLUSH, null, "j")
    }
    fun speak(t: String) {
        stopSpeak()
        val j = cfg(); val k = j.optString("vkey")
        if (k.isEmpty()) { deep(t); return }
        Thread {
            try {
                val id = j.optString("vid").ifEmpty { "pNInz6obpgDQGcFmaJgB" }
                val body = JSONObject().put("text", t.replace(Regex("[*_`#]"), "")).put("model_id", "eleven_multilingual_v2").toString()
                val (code, b) = post("https://api.elevenlabs.io/v1/text-to-speech/$id", body, mapOf("xi-api-key" to k))
                if (code < 300) {
                    val f = File(c.cacheDir, "v.mp3"); f.writeBytes(b)
                    h.post { play(f) }; return@Thread
                }
            } catch (e: Exception) {}
            h.post { deep(t) }
        }.start()
    }
    fun play(f: File) {
        try {
            val m = MediaPlayer(); mp = m
            m.setDataSource(f.path); m.prepare()
            m.setOnCompletionListener { ev("mode", "idle") }
            m.start(); ev("mode", "speak"); pulser()
        } catch (e: Exception) { ev("mode", "idle") }
    }
    fun listen(cb: (String) -> Unit) {
        h.post {
            try { sr?.destroy() } catch (e: Exception) {}
            tts?.stop()
            val s = SpeechRecognizer.createSpeechRecognizer(c); sr = s
            s.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(r: Float) { ev("pulse", ((r + 2f) / 12f).coerceIn(0f, 1f).toString()) }
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(e: Int) { ev("mode", "idle") }
                override fun onResults(r: Bundle?) {
                    val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (t.isNullOrEmpty()) ev("mode", "idle") else { ev("heard", t); cb(t) }
                }
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            s.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, "free_form").putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR"))
            ev("mode", "listen")
        }
    }
    fun post(u: String, body: String, hd: Map<String, String> = mapOf()): Pair<Int, ByteArray> {
        val k = URL(u).openConnection() as HttpURLConnection
        k.requestMethod = "POST"; k.doOutput = true; k.connectTimeout = 20000; k.readTimeout = 60000
        k.setRequestProperty("Content-Type", "application/json")
        hd.forEach { (a, b) -> k.setRequestProperty(a, b) }
        k.outputStream.use { it.write(body.toByteArray()) }
        val code = k.responseCode
        val s = if (code < 400) k.inputStream else k.errorStream
        return Pair(code, s.readBytes())
    }
    fun think(): String {
        val j = cfg(); val key = j.optString("key")
        if (key.isEmpty()) return "Configure sua API Key nas configurações para eu ter cérebro."
        val mem = j.optJSONArray("mem")?.let { a -> (0 until a.length()).joinToString("; ") { a.getString(it) } } ?: ""
        val sys = "Você é ${j.optString("name", "Jarvis")}, assistente pessoal estilo Jarvis no Android de ${j.optString("user").ifEmpty { "seu usuário" }}. " +
            "Personalidade: ${j.optString("pers")}. Responda curto (1 a 3 frases), natural para ser falado, sem markdown. " +
            "Você abre apps, pesquisa no YouTube, clica, rola e digita na tela quando o usuário dá comandos diretos. " +
            "Memória do usuário: ${mem.ifEmpty { "nada ainda" }}. Agora: ${Date()}."
        return try {
            val model = j.optString("model").ifEmpty { "gemini-2.0-flash" }
            if (j.optString("prov", "gemini") == "gemini") {
                val cs = JSONArray()
                hist.forEach { (r, x) -> cs.put(JSONObject().put("role", r).put("parts", JSONArray().put(JSONObject().put("text", x)))) }
                val body = JSONObject().put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys)))).put("contents", cs)
                val (_, b) = post("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$key", body.toString())
                val o = JSONObject(String(b))
                if (o.has("error")) "Erro: " + o.getJSONObject("error").optString("message")
                else o.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
            } else {
                val ms = JSONArray().put(JSONObject().put("role", "system").put("content", sys))
                hist.forEach { (r, x) -> ms.put(JSONObject().put("role", if (r == "user") "user" else "assistant").put("content", x)) }
                val base = j.optString("base").ifEmpty { "https://api.openai.com/v1" }.trimEnd('/')
                val (_, b) = post("$base/chat/completions", JSONObject().put("model", model).put("messages", ms).toString(), mapOf("Authorization" to "Bearer $key"))
                val o = JSONObject(String(b))
                if (o.has("error")) "Erro: " + o.getJSONObject("error").optString("message")
                else o.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
            }
        } catch (e: Exception) { "Falha: ${e.message}" }
    }
    fun go(i: Intent) { c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    fun acc(f: (JarvisAccess) -> String): String = JarvisAccess.i?.let(f) ?: "Ative o controle de apps nas configurações do Jarvis."
    fun openApp(n0: String): String {
        val n = n0.trim().removePrefix("o ").removePrefix("a ").removePrefix("app ").removePrefix("aplicativo ")
        val pm = c.packageManager
        val ls = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val m = ls.map { it to it.loadLabel(pm).toString().lowercase() }
        val hit = m.firstOrNull { it.second == n } ?: m.firstOrNull { it.second.contains(n) } ?: m.firstOrNull { it.second.length > 2 && n.contains(it.second) }
        if (hit == null) return "Não achei o app $n."
        val li = pm.getLaunchIntentForPackage(hit.first.activityInfo.packageName) ?: return "Não consegui abrir $n."
        go(li)
        return "Abrindo ${hit.second}."
    }
    fun local(t: String): String? {
        val l = t.lowercase().trim().trimEnd('.', '!', '?')
        Regex("^(?:jarvis,? )?(?:lembra|lembre|memorize|anote)(?: que| de)? (.+)").find(l)?.let {
            val j = cfg(); val a = j.optJSONArray("mem") ?: JSONArray()
            a.put(it.groupValues[1]); j.put("mem", a); save(j.toString()); return "Memorizado."
        }
        Regex("(?:pesquis[ae]|toca|toque|abr[ae]|procura|busca) (?:por )?(.+?) no youtube").find(l)?.let {
            val q = it.groupValues[1]
            go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + URLEncoder.encode(q, "UTF-8"))))
            return "Pesquisando $q no YouTube."
        }
        Regex("^(?:abr[ae]|abrir|inicia|iniciar|executa) (.+)").find(l)?.let { return openApp(it.groupValues[1]) }
        Regex("^(?:clica|clique|toca|toque) (?:em |no |na )?(.+)").find(l)?.let { return acc { a -> a.clickText(it.groupValues[1]) } }
        Regex("^digit[ae] (.+)").find(l)?.let { return acc { a -> a.type(it.groupValues[1]) } }
        if (Regex("^(?:sobe|subir|rola(?:r)? (?:pra|para) cima)").containsMatchIn(l)) return acc { it.scroll(false) }
        if (Regex("^(?:rola|rolar|desce|descer)").containsMatchIn(l)) return acc { it.scroll(true) }
        if (Regex("^(?:volta|voltar)$").matches(l)) return acc { it.glob(AccessibilityService.GLOBAL_ACTION_BACK) }
        if (Regex("^(?:início|inicio|home|tela inicial)$").matches(l)) return acc { it.glob(AccessibilityService.GLOBAL_ACTION_HOME) }
        if (l == "recentes") return acc { it.glob(AccessibilityService.GLOBAL_ACTION_RECENTS) }
        if (Regex("que horas").containsMatchIn(l)) return "Agora são " + java.text.SimpleDateFormat("HH:mm", Locale("pt", "BR")).format(Date()) + "."
        return null
    }
    fun ask(t: String) {
        ev("mode", "think")
        Thread {
            hist.add("user" to t)
            val r = try { local(t) ?: think() } catch (e: Exception) { "Falha: ${e.message}" }
            hist.add("model" to r)
            while (hist.size > 24) hist.removeAt(0)
            ev("reply", r)
            h.post { speak(r) }
        }.start()
    }
}
