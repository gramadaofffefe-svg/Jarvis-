package com.jarvis.app
import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import java.io.ByteArrayOutputStream

class CamActivity : Activity() {
    var uri: Uri? = null
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val v = ContentValues().apply { put(MediaStore.Images.Media.DISPLAY_NAME, "jarvis_${System.currentTimeMillis()}.jpg"); put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg") }
        uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)
        startActivityForResult(Intent(MediaStore.ACTION_IMAGE_CAPTURE).putExtra(MediaStore.EXTRA_OUTPUT, uri), 1)
    }
    override fun onActivityResult(rq: Int, rs: Int, d: Intent?) {
        super.onActivityResult(rq, rs, d)
        val q = intent.getStringExtra("q") ?: "O que é isso?"
        try {
            val u = uri
            if (rs == RESULT_OK && u != null) {
                val bm = BitmapFactory.decodeStream(contentResolver.openInputStream(u), null, BitmapFactory.Options().apply { inSampleSize = 4 })!!
                val sc = Bitmap.createScaledBitmap(bm, 720, (720f * bm.height / bm.width).toInt(), true)
                val o = ByteArrayOutputStream(); sc.compress(Bitmap.CompressFormat.JPEG, 70, o)
                Brain.pendingImg = Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
                contentResolver.delete(u, null, null)
                Brain.ask("[foto da câmera] $q")
            } else if (u != null) contentResolver.delete(u, null, null)
        } catch (e: Exception) { Brain.ev("reply", "Não consegui ler a foto.") }
        finish()
    }
}
