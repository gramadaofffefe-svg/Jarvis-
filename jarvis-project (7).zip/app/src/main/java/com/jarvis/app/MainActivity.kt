package com.jarvis.app
import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.webkit.*
import org.json.JSONObject

class MainActivity : Activity() {
    lateinit var wv: WebView
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Brain.init(applicationContext)
        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS, "android.permission.READ_MEDIA_IMAGES", "android.permission.BLUETOOTH_CONNECT", "android.permission.READ_MEDIA_VIDEO"), 1)
        wv = WebView(this); setContentView(wv)
        wv.settings.javaScriptEnabled = true; wv.settings.domStorageEnabled = true
        wv.setBackgroundColor(0xFF02060D.toInt())
        wv.webChromeClient = WebChromeClient()
        wv.addJavascriptInterface(Bridge(), "Android")
        Brain.ui = { m, t -> runOnUiThread { wv.evaluateJavascript("nativeEvt('$m',${JSONObject.quote(t)})", null) } }
        wv.loadUrl("file:///android_asset/index.html")
        share(intent)
    }
    override fun onNewIntent(i: Intent) { super.onNewIntent(i); share(i) }
    fun share(i: Intent?) {
        if (i?.action != Intent.ACTION_SEND) return
        @Suppress("DEPRECATION") val u = i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
        val tx = i.getStringExtra(Intent.EXTRA_TEXT)
        Thread {
            Thread.sleep(1500)
            if (u != null) { val r = try { if ((contentResolver.getType(u) ?: "").startsWith("video/")) Brain.cutSilence(u) else Brain.scanFile(u) } catch (e: Exception) { "Não consegui analisar o arquivo." }; Brain.ev("reply", r); Brain.h.post { Brain.speak(r) } }
            else if (tx != null) Brain.ask("Analise este texto ou link e diga se é golpe ou perigoso: $tx")
        }.start()
    }
    inner class Bridge {
        @JavascriptInterface fun getCfg(): String = Brain.raw()
        @JavascriptInterface fun saveCfg(s: String) { Brain.save(s) }
        @JavascriptInterface fun ask(t: String) { Brain.ask(t) }
        @JavascriptInterface fun listen() { Brain.listen { Brain.ask(it) } }
        @JavascriptInterface fun speak(t: String) { Brain.h.post { Brain.speak(t) } }
        @JavascriptInterface fun voices(): String = Brain.voices()
        @JavascriptInterface fun bubble() {
            runOnUiThread {
                if (Settings.canDrawOverlays(this@MainActivity)) startForegroundService(Intent(this@MainActivity, BubbleService::class.java))
                else startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        }
        @JavascriptInterface fun bubbleOff() { stopService(Intent(this@MainActivity, BubbleService::class.java)) }
        @JavascriptInterface fun notif() { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        @JavascriptInterface fun usage() { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        @JavascriptInterface fun access() { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
    }
}
