package com.jarvis.app
import android.accessibilityservice.AccessibilityService
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.provider.AlarmClock
import android.view.KeyEvent
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.media.MediaPlayer
import android.util.Base64
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.*

object Brain {
    lateinit var c: Context
    val h = Handler(Looper.getMainLooper())
    var tts: TextToSpeech? = null
    var ui: (String, String) -> Unit = { _, _ -> }
    var mode = "idle"
    var pulse = 0f
    val hist = ArrayList<Pair<String, String>>()
    var mp: MediaPlayer? = null
    var sr: SpeechRecognizer? = null
    @Volatile var cancel = false
    var track: AudioTrack? = null

    fun init(x: Context) {
        if (::c.isInitialized) return
        c = x
        h.post { regCtx(); regProx() }
        tts = TextToSpeech(c) { st ->
            if (st == 0) {
                tts?.language = Locale("pt", "BR")
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(u: String?) { ev("mode", "speak"); h.post { pulser() } }
                    override fun onDone(u: String?) { ev("mode", "idle"); onSpeechEnd() }
                    override fun onError(u: String?) { ev("mode", "idle") }
                })
            }
        }
    }
    fun raw(): String = c.getSharedPreferences("j", 0).getString("cfg", "{}") ?: "{}"
    fun save(s: String) { c.getSharedPreferences("j", 0).edit().putString("cfg", s).apply() }
    fun cfg(): JSONObject = try { JSONObject(raw()) } catch (e: Exception) { JSONObject() }
    fun ev(m: String, t: String = "") {
        if (m == "mode") mode = t
        if (m == "pulse") pulse = t.toFloatOrNull() ?: 0.9f
        h.post { try { ui(m, t) } catch (e: Exception) {} }
    }
    fun voices(): String {
        val a = JSONArray()
        tts?.voices?.filter { it.locale.language == "pt" }?.sortedBy { it.name }?.forEach { a.put(it.name) }
        return a.toString()
    }
    fun pulser() {
        if (mode == "speak") { ev("pulse", (0.4f + Random().nextFloat() * 0.5f).toString()); h.postDelayed({ pulser() }, 130) }
    }
    fun stopSpeak() { cancel = true; try { sr?.cancel() } catch (e: Exception) {}; stopAudio() }
    fun stopAudio() {
        tts?.stop()
        try { mp?.release() } catch (e: Exception) {}
        try { track?.stop(); track?.release() } catch (e: Exception) {}
        mp = null; track = null; ev("mode", "idle")
    }
    fun onSpeechEnd() {
        if (!cancel && cfg().optBoolean("conv", false)) h.postDelayed({ if (!cancel && mode == "idle") listen { ask(it) } }, 500)
    }
    fun setCfg(k: String, v: Any) { val j = cfg(); j.put(k, v); save(j.toString()) }
    fun addMem(f: String) {
        val j = cfg(); if (!j.optBoolean("amem", true)) return
        val a = j.optJSONArray("mem") ?: JSONArray()
        for (i in 0 until a.length()) if (a.getString(i).equals(f, true)) return
        if (a.length() > 500) a.remove(0)
        a.put(f.take(160)); j.put("mem", a); save(j.toString())
    }
    fun mkTrack(n: Int, sr: Int, mode: Int): AudioTrack = AudioTrack.Builder()
        .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
        .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(sr).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
        .setBufferSizeInBytes(n).setTransferMode(mode).build()
    fun sfx(k: String) {
        if (!cfg().optBoolean("sfx", true)) return
        Thread {
            val sr = 22050
            val seq = when (k) {
                "on" -> listOf(520.0 to 70, 780.0 to 70, 1170.0 to 110)
                "think" -> listOf(660.0 to 50, 880.0 to 50)
                "done" -> listOf(880.0 to 70, 660.0 to 110)
                else -> listOf(1400.0 to 35)
            }
            val buf = ShortArray(sr * seq.sumOf { it.second } / 1000); var i = 0
            for ((f, ms) in seq) {
                val n = sr * ms / 1000
                for (x in 0 until n) { val env = Math.min(1.0, Math.min(x, n - x) / (sr * 0.01)); buf[i++] = (Math.sin(2 * Math.PI * f * x / sr) * env * 9000).toInt().toShort() }
            }
            try {
                val at = mkTrack(buf.size * 2, sr, AudioTrack.MODE_STATIC)
                at.write(buf, 0, buf.size); at.play()
                Thread.sleep(seq.sumOf { it.second } + 120L); at.release()
            } catch (e: Exception) {}
        }.start()
    }
    fun playPcm(b: ByteArray) {
        val at = mkTrack(b.size, 24000, AudioTrack.MODE_STATIC)
        at.write(b, 0, b.size); track = at
        at.setNotificationMarkerPosition(b.size / 2 - 1)
        at.setPlaybackPositionUpdateListener(object : AudioTrack.OnPlaybackPositionUpdateListener {
            override fun onMarkerReached(t: AudioTrack?) { ev("mode", "idle"); onSpeechEnd() }
            override fun onPeriodicNotification(t: AudioTrack?) {}
        })
        ev("mode", "speak"); h.post { pulser() }
        at.play()
    }
    fun gtts(t: String): Boolean {
        val j = cfg(); val voice = j.optString("gv"); if (voice.isEmpty()) return false
        var key = if (j.optString("prov", "gemini") == "gemini") j.optString("key") else ""
        if (key.isEmpty()) j.optJSONArray("provs")?.let { a -> for (i in 0 until a.length()) { val p = a.getJSONObject(i); if (p.optString("t") == "gemini" && key.isEmpty()) key = p.optString("k") } }
        if (key.isEmpty()) return false
        val model = j.optString("gvm").ifEmpty { "gemini-2.5-flash-preview-tts" }
        val txt = style() + ": " + t.replace(Regex("[*_`#]"), "")
        val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", txt)))))
            .put("generationConfig", JSONObject().put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig", JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice)))))
        val o = JSONObject(String(post("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$key", body.toString()).second))
        if (o.has("error")) return false
        val d = o.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getJSONObject("inlineData").getString("data")
        playPcm(Base64.decode(d, Base64.DEFAULT)); return true
    }
    fun deep(t: String) {
        val j = cfg(); val tt = tts ?: return
        val vs = tt.voices?.filter { it.locale.language == "pt" } ?: listOf()
        val want = j.optString("voice")
        val v = vs.firstOrNull { it.name == want } ?: vs.firstOrNull {
            val n = it.name.lowercase(); (n.contains("ptd") || n.contains("pte") || n.contains("male")) && !n.contains("female")
        }
        if (v != null) tt.voice = v else tt.language = Locale("pt", "BR")
        tt.setPitch(j.optString("pitch", "0.6").toFloatOrNull() ?: 0.6f)
        tt.setSpeechRate((j.optString("rate", "0.92").toFloatOrNull() ?: 0.92f) * (if (Calendar.getInstance().get(Calendar.HOUR_OF_DAY) in 0..5) 0.9f else 1f))
        tt.speak(t.replace(Regex("[*_`#]"), ""), TextToSpeech.QUEUE_FLUSH, null, "j")
    }
    fun play(f: File) {
        try {
            val m = MediaPlayer(); mp = m
            m.setDataSource(f.path); m.prepare()
            m.setOnCompletionListener { ev("mode", "idle"); onSpeechEnd() }
            m.start(); ev("mode", "speak"); pulser()
        } catch (e: Exception) { ev("mode", "idle") }
    }
    fun listen(cb: (String) -> Unit) {
        h.post {
            try { sr?.destroy() } catch (e: Exception) {}
            tts?.stop()
            val s = SpeechRecognizer.createSpeechRecognizer(c); sr = s
            s.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(r: Float) { ev("pulse", ((r + 2f) / 12f).coerceIn(0f, 1f).toString()) }
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(e: Int) { ev("mode", "idle") }
                override fun onResults(r: Bundle?) {
                    val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (t.isNullOrEmpty()) ev("mode", "idle") else { ev("heard", t); cb(t) }
                }
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            sfx("on"); ev("mode", "listen")
            h.postDelayed({ s.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, "free_form").putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")) }, 350)
        }
    }
    fun post(u: String, body: String, hd: Map<String, String> = mapOf()): Pair<Int, ByteArray> {
        val k = URL(u).openConnection() as HttpURLConnection
        k.requestMethod = "POST"; k.doOutput = true; k.connectTimeout = 20000; k.readTimeout = 60000
        k.setRequestProperty("Content-Type", "application/json")
        hd.forEach { (a, b) -> k.setRequestProperty(a, b) }
        k.outputStream.use { it.write(body.toByteArray()) }
        val code = k.responseCode
        val s = if (code < 400) k.inputStream else k.errorStream
        return Pair(code, s.readBytes())
    }
    fun one(p: JSONObject, sys: String, user: String, img: String?): String {
        val key = p.optString("k")
        val (rt, rb, model) = resolve(p)
        if (rt == "custom") return custom(p, sys, user)
        if (rt == "gemini") {
            var err = ""
            for (m in listOf(model, "gemini-flash-latest")) {
                val parts = JSONArray().put(JSONObject().put("text", user))
                if (img != null) for (im in img.split("|")) parts.put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", im)))
                val body = JSONObject()
                    .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
                    .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
                    .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
                val o = JSONObject(String(post("https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent?key=$key", body.toString()).second))
                if (!o.has("error")) return o.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
                err = o.getJSONObject("error").optString("message")
            }
            throw Exception(err)
        }
        if (rt == "anthropic") return claude(rb, key, model, sys, user, img)
        val content: Any = if (img == null) user else JSONArray().also { ja ->
            ja.put(JSONObject().put("type", "text").put("text", user))
            for (im in img.split("|")) ja.put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$im")))
        }
        val ms = JSONArray().put(JSONObject().put("role", "system").put("content", sys)).put(JSONObject().put("role", "user").put("content", content))
        return oai(rb, key, model, ms)
    }
    fun llm(sys: String, user: String, img: String?): String {
        val j = cfg(); val l = ArrayList<JSONObject>()
        if (j.optString("key").isNotEmpty() || j.optString("base").isNotEmpty()) l.add(JSONObject().put("n", "Principal").put("t", j.optString("prov", "gemini")).put("k", j.optString("key")).put("m", j.optString("model")).put("b", j.optString("base")))
        j.optJSONArray("provs")?.let { a -> for (i in 0 until a.length()) { val p = a.getJSONObject(i); if (p.optString("k").isNotEmpty() || p.optString("b").isNotEmpty()) l.add(p) } }
        if (l.isEmpty()) throw Exception("Configure uma API Key nas configurações.")
        var err = ""
        for (p in l) {
            try { return one(p, sys, user, img) } catch (e: Exception) {
                err = "${p.optString("n")}: ${e.message}"; ev("step", "⚠ ${p.optString("n", "IA")} falhou, passando para a próxima IA…")
            }
        }
        throw Exception(err)
    }
    fun custom(p: JSONObject, sys: String, user: String): String {
        val key = p.optString("k"); val model = p.optString("m")
        fun esc(x: String) = JSONObject.quote(x).let { it.substring(1, it.length - 1) }
        val url = p.optString("b").replace("{KEY}", key).replace("{MODEL}", model)
        val hd = HashMap<String, String>()
        p.optString("h").lines().forEach { ln -> val i = ln.indexOf(':'); if (i > 0) hd[ln.substring(0, i).trim()] = ln.substring(i + 1).trim().replace("{KEY}", key) }
        val body = p.optString("bd").replace("{SYSTEM}", esc(sys)).replace("{PROMPT}", esc(user)).replace("{MODEL}", model).replace("{KEY}", key)
        val raw = String(post(url, body, hd).second).trim()
        if (!raw.startsWith("{") && !raw.startsWith("[")) throw Exception("a API devolveu algo que não é JSON; confira a URL")
        var o: Any = if (raw.startsWith("[")) JSONArray(raw) else JSONObject(raw)
        for (seg in p.optString("rp").split(".").filter { it.isNotEmpty() }) { val cur = o; o = if (cur is JSONArray) cur.get(seg.toInt()) else (cur as JSONObject).get(seg) }
        return o.toString()
    }
    fun settle(minMs: Long) {
        Thread.sleep(minMs)
        val a = JarvisAccess.i ?: return
        var prev = a.sig()
        for (i in 0 until 6) { Thread.sleep(450); val s = a.sig(); if (s == prev) return; prev = s }
    }
    fun offlineMsg(e: Exception): String {
        val m = e.message ?: ""
        return if (Regex("Unable to resolve|timeout|timed out|Failed to connect|unreachable|ECONN", RegexOption.IGNORE_CASE).containsMatchIn(m))
            "Estou sem conexão com a IA. Sem internet ainda faço: abrir apps, música, volume, lanterna, timer, alarme, rotinas, aparelhos da rede local, editar fotos, cartas e faxina. Dica: configure uma IA local, como o Ollama no Termux, para eu pensar offline."
        else "Falha: $m"
    }
    fun pcAct(arg: String): String {
        val pc = cfg().optJSONObject("pc") ?: return "PC não conectado. Digite: conecta no pc IP:PORTA CÓDIGO"
        val sp = arg.trim().split(" ", limit = 2)
        return try {
            val body = JSONObject().put("action", sp[0]).put("arg", sp.getOrElse(1) { "" }).toString()
            val (code, b) = post("http://${pc.optString("host")}/act", body, mapOf("X-Token" to pc.optString("token")))
            if (code == 200) JSONObject(String(b)).optString("msg", "ok") else "o PC recusou (código $code)"
        } catch (e: Exception) { "Não consegui falar com o PC: ${e.message}" }
    }
    fun discover(): String {
        val nsd = c.getSystemService(Context.NSD_SERVICE) as android.net.nsd.NsdManager
        val types = mapOf("_googlecast._tcp" to "TV ou caixa de som (Chromecast)", "_hue._tcp" to "lâmpadas (Hue Bridge)", "_matter._tcp" to "Matter", "_airplay._tcp" to "TV ou caixa (AirPlay)",
            "_spotify-connect._tcp" to "caixa de som (Spotify)", "_homekit._tcp" to "HomeKit", "_ipp._tcp" to "impressora", "_http._tcp" to "aparelho web (tomada, lâmpada, ar-condicionado)")
        val found = java.util.Collections.synchronizedList(ArrayList<String>())
        val ls = ArrayList<android.net.nsd.NsdManager.DiscoveryListener>()
        for ((tp, k) in types) {
            val l = object : android.net.nsd.NsdManager.DiscoveryListener {
                override fun onDiscoveryStarted(s: String) {}
                override fun onDiscoveryStopped(s: String) {}
                override fun onStartDiscoveryFailed(s: String, e: Int) {}
                override fun onStopDiscoveryFailed(s: String, e: Int) {}
                override fun onServiceLost(i: android.net.nsd.NsdServiceInfo) {}
                override fun onServiceFound(i: android.net.nsd.NsdServiceInfo) { found.add("${i.serviceName} ($k, Wi-Fi)") }
            }
            try { nsd.discoverServices(tp, android.net.nsd.NsdManager.PROTOCOL_DNS_SD, l); ls.add(l) } catch (e: Exception) {}
        }
        Thread.sleep(6000)
        ls.forEach { try { nsd.stopServiceDiscovery(it) } catch (e: Exception) {} }
        val bt = try { (c.getSystemService(Context.BLUETOOTH_SERVICE) as android.bluetooth.BluetoothManager).adapter?.bondedDevices?.map { "${it.name} (Bluetooth)" } ?: listOf() } catch (e: Exception) { listOf() }
        val all = (found.distinct() + bt).take(25)
        return if (all.isEmpty()) "Não achei nada. Confira se o celular está no mesmo Wi-Fi dos aparelhos e se você aceitou a permissão de Bluetooth."
        else "Encontrei ${all.size}: " + all.joinToString("; ") + ". Para controlar um deles, cadastre: cadastra dispositivo NOME, liga URL, desliga URL."
    }
    fun scanFile(u: Uri): String {
        var name = "arquivo"; var size = 0L
        c.contentResolver.query(u, null, null, null, null)?.use { cu ->
            if (cu.moveToFirst()) {
                val i = cu.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME); if (i >= 0) name = cu.getString(i)
                val j = cu.getColumnIndex(android.provider.OpenableColumns.SIZE); if (j >= 0) size = cu.getLong(j)
            }
        }
        val md = java.security.MessageDigest.getInstance("SHA-256")
        c.contentResolver.openInputStream(u)?.use { s -> val b = ByteArray(65536); while (true) { val n = s.read(b); if (n < 0) break; md.update(b, 0, n) } }
        val hash = md.digest().joinToString("") { "%02x".format(it) }
        val ln = name.lowercase(); val risks = ArrayList<String>()
        if (Regex("\\.(apk|xapk|apks|exe|msi|bat|cmd|scr|com|jar|js|vbs|ps1|sh|dll|lnk|iso|dmg|pkg)$").containsMatchIn(ln)) risks.add("é um executável ou instalador")
        if (Regex("\\.(pdf|docx?|xlsx?|jpg|png|mp4|mp3|txt)\\.(apk|exe|scr|bat|js|vbs|jar|zip)$").containsMatchIn(ln)) risks.add("extensão dupla disfarçada")
        if (Regex("\\.(docm|xlsm|pptm)$").containsMatchIn(ln)) risks.add("documento com macros")
        if (Regex("\\.(zip|rar|7z)$").containsMatchIn(ln)) risks.add("compactado, não dá para ver o conteúdo")
        val lvl = if (risks.isEmpty()) "Não vi sinais de perigo no nome nem no tipo de" else "ATENÇÃO, " + risks.joinToString("; ") + ":"
        return "$lvl $name (${size / 1024} KB). Isso não é um antivírus. Só abra ou instale se confiar em quem enviou. SHA-256 ${hash.take(16)}… confira no VirusTotal."
    }
    fun makeProject(desc: String): String = try {
        val raw = llm("Você é um programador sênior. Responda só JSON {\"name\":\"nome-curto\",\"files\":[{\"path\":\"pasta/arquivo.ext\",\"content\":\"conteúdo completo\"}]} com um projeto completo e funcional, sem placeholders.", "Crie o projeto: $desc", null)
        val o = JSONObject(raw.substring(raw.indexOf('{'), raw.lastIndexOf('}') + 1))
        val n = o.getString("name").lowercase().replace(Regex("[^a-z0-9-]"), "-").take(30)
        val fs = o.getJSONArray("files")
        val v = android.content.ContentValues().apply { put(android.provider.MediaStore.Downloads.DISPLAY_NAME, "jarvis-$n.zip"); put(android.provider.MediaStore.Downloads.MIME_TYPE, "application/zip") }
        val u = c.contentResolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)!!
        java.util.zip.ZipOutputStream(c.contentResolver.openOutputStream(u)).use { z ->
            for (i in 0 until fs.length()) { val f = fs.getJSONObject(i); z.putNextEntry(java.util.zip.ZipEntry(n + "/" + f.getString("path").replace("..", "").trimStart('/'))); z.write(f.getString("content").toByteArray()); z.closeEntry() }
        }
        "Pronto! Criei o projeto $n com ${fs.length()} arquivos e salvei em Downloads como jarvis-$n.zip."
    } catch (e: Exception) { "Não consegui montar o projeto: ${e.message}" }
    fun limites(): String {
        val l = ArrayList<String>()
        if (JarvisAccess.i == null) l.add("sem a acessibilidade eu não leio a tela nem clico em nada")
        if (NotifService.recent.isEmpty()) l.add("se eu não estiver vendo suas notificações, ative o acesso a elas")
        if (cfg().optJSONObject("pc") == null) l.add("sem o programa no computador eu não controlo o PC")
        if (dev().length() == 0) l.add("sem aparelhos cadastrados eu não controlo a casa, e cada aparelho precisa de um endereço de controle")
        l.add("não jogo em tempo real nem em jogos online competitivos: reajo em segundos e isso seria trapaça")
        l.add("não leio telas de apps que bloqueiam captura, como bancos")
        l.add("posso errar toques em telas desenhadas por imagem; peça um passo de cada vez")
        l.add("o editor de vídeo só corta silêncios, sem legenda, zoom ou efeitos; em CapCut e similares eu só faço o que dá para tocar na tela")
        l.add("sem internet uso só as funções locais, a não ser que você configure uma IA local")
        return "Meus limites hoje: " + l.joinToString("; ") + "."
    }
    fun local6(l: String, t: String): String? {
        Regex("^conecta(?:r)? (?:no|ao|com o) (?:meu )?(?:pc|computador) (\\S+) (\\S+)$", RegexOption.IGNORE_CASE).find(t.trim())?.let {
            val j = cfg(); j.put("pc", JSONObject().put("host", it.groupValues[1]).put("token", it.groupValues[2])); save(j.toString())
            return "Computador salvo. Teste: " + pcAct("ping")
        }
        Regex("^(?:no|pro|para o|do) (?:meu )?(?:pc|computador),? (.+)$").find(l)?.let { return agent("Use a ação pc para fazer isso no computador: ${it.groupValues[1]}") }
        if (Regex("procura(?:r)? (?:por )?dispositivos|descobre dispositivos|painel de dispositivos").containsMatchIn(l)) return discover()
        Regex("^importa(?:r)? dispositivos (\\{.*\\})$", RegexOption.IGNORE_CASE).find(t.trim())?.let {
            return try {
                val inp = JSONObject(it.groupValues[1]); val j = cfg(); val d = j.optJSONObject("devices") ?: JSONObject()
                for (k in inp.keys()) d.put(k.lowercase(), inp.getJSONObject(k)); j.put("devices", d); save(j.toString()); "Importei ${inp.length()} dispositivos."
            } catch (e: Exception) { "JSON inválido: ${e.message}" }
        }
        if (Regex("(?:o que|que) (?:você|voce|tu) (?:não|nao) (?:consegue|sabe|pode) fazer|suas limitações|seus limites").containsMatchIn(l)) return limites()
        Regex("^(?:cria|crie|monta|monte|gera|gere|programa|programe)(?:r)? (?:pra mim |para mim |um |uma )*projeto (?:de |para |que |pra )?(.+)$").find(l)?.let { return makeProject(it.groupValues[1]) }
        return null
    }
    fun latestVideo(): Uri? {
        val base = android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        try {
            c.contentResolver.query(base, arrayOf(android.provider.MediaStore.Video.Media._ID), null, null, "${android.provider.MediaStore.Video.Media.DATE_ADDED} DESC")?.use { cu ->
                if (cu.moveToFirst()) return android.content.ContentUris.withAppendedId(base, cu.getLong(0))
            }
        } catch (e: Exception) {}
        return null
    }
    fun cutSilence(u: Uri): String {
        var out: Uri? = null
        try {
            val ex = MediaExtractor(); ex.setDataSource(c, u, null)
            var ai = -1
            for (i in 0 until ex.trackCount) if ((ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) { ai = i; break }
            if (ai < 0) return "Esse vídeo não tem áudio para eu achar os silêncios."
            ex.selectTrack(ai)
            val fmt = ex.getTrackFormat(ai)
            val codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
            codec.configure(fmt, null, null, 0); codec.start()
            val bi = MediaCodec.BufferInfo()
            val ts = ArrayList<Long>(); val lv = ArrayList<Double>(); val du = ArrayList<Long>()
            var eos = false; var done = false
            val sr = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE).toDouble(); val ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            while (!done && !cancel) {
                if (!eos) {
                    val ii = codec.dequeueInputBuffer(10000)
                    if (ii >= 0) {
                        val n = ex.readSampleData(codec.getInputBuffer(ii)!!, 0)
                        if (n < 0) { codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); eos = true }
                        else { codec.queueInputBuffer(ii, 0, n, ex.sampleTime, 0); ex.advance() }
                    }
                }
                val oi = codec.dequeueOutputBuffer(bi, 10000)
                if (oi >= 0) {
                    val sb = codec.getOutputBuffer(oi)!!.order(java.nio.ByteOrder.nativeOrder()).asShortBuffer()
                    var s = 0.0; val n = sb.remaining()
                    for (i in 0 until n) { val x = sb.get().toDouble(); s += x * x }
                    if (n > 0) { ts.add(bi.presentationTimeUs); lv.add(Math.sqrt(s / n)); du.add((n / ch / sr * 1e6).toLong()) }
                    codec.releaseOutputBuffer(oi, false)
                    if ((bi.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) done = true
                }
            }
            codec.stop(); codec.release(); ex.release()
            if (cancel) return "Cancelado."
            if (ts.size < 10) return "Não consegui analisar o áudio desse vídeo."
            val sorted = lv.sorted(); val lo = sorted[sorted.size / 5]; val hi = sorted[sorted.size * 4 / 5]
            val th = lo + 0.25 * (hi - lo)
            val total = ts.last() + du.last()
            val keep = ArrayList<Pair<Long, Long>>(); var segStart = 0L; var silStart = -1L; val pad = 150000L
            for (i in ts.indices) {
                val silent = lv[i] < th
                if (silent && silStart < 0) silStart = ts[i]
                if (!silent && silStart >= 0) {
                    if (ts[i] - silStart >= 700000L) { val a = silStart + pad; val b = ts[i] - pad; if (b > a) { if (a > segStart) keep.add(Pair(segStart, a)); segStart = b } }
                    silStart = -1L
                }
            }
            if (silStart >= 0 && total - silStart >= 700000L) keep.add(Pair(segStart, silStart + pad)) else keep.add(Pair(segStart, total))
            val kept = keep.filter { it.second - it.first >= 300000L }
            val keptLen = kept.sumOf { it.second - it.first }
            if (kept.isEmpty() || total - keptLen < 1500000L) return "Não achei silêncios longos o bastante para cortar."
            val mr = MediaMetadataRetriever(); mr.setDataSource(c, u)
            val rot = mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0; mr.release()
            val cv = android.content.ContentValues().apply {
                put(android.provider.MediaStore.Video.Media.DISPLAY_NAME, "jarvis_cut_${System.currentTimeMillis()}.mp4")
                put(android.provider.MediaStore.Video.Media.MIME_TYPE, "video/mp4"); put(android.provider.MediaStore.Video.Media.RELATIVE_PATH, "Movies/Jarvis")
            }
            val dst = c.contentResolver.insert(android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)!!; out = dst
            val pfd = c.contentResolver.openFileDescriptor(dst, "w")!!
            val mux = MediaMuxer(pfd.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val vEx = MediaExtractor(); vEx.setDataSource(c, u, null); val aEx = MediaExtractor(); aEx.setDataSource(c, u, null)
            var vi = -1; var ai2 = -1
            for (i in 0 until vEx.trackCount) { val m = vEx.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: ""; if (m.startsWith("video/") && vi < 0) vi = i; if (m.startsWith("audio/") && ai2 < 0) ai2 = i }
            if (vi < 0 || ai2 < 0) { pfd.close(); c.contentResolver.delete(dst, null, null); return "Não achei vídeo e áudio no arquivo." }
            vEx.selectTrack(vi); aEx.selectTrack(ai2); mux.setOrientationHint(rot)
            val vt = mux.addTrack(vEx.getTrackFormat(vi)); val at = mux.addTrack(aEx.getTrackFormat(ai2)); mux.start()
            val buf = java.nio.ByteBuffer.allocate(2 * 1024 * 1024); val info = MediaCodec.BufferInfo(); var off = 0L
            for ((s, e) in kept) {
                vEx.seekTo(s, MediaExtractor.SEEK_TO_PREVIOUS_SYNC); val base = vEx.sampleTime; if (base < 0) continue
                aEx.seekTo(base, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
                var lastV = base
                while (true) {
                    val t = vEx.sampleTime; if (t < 0 || t > e) break
                    info.size = vEx.readSampleData(buf, 0); if (info.size < 0) break
                    info.offset = 0; info.presentationTimeUs = off + (t - base)
                    info.flags = if ((vEx.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                    mux.writeSampleData(vt, buf, info); lastV = t; vEx.advance()
                }
                while (true) {
                    val t = aEx.sampleTime; if (t < 0 || t > lastV) break
                    if (t < base) { aEx.advance(); continue }
                    info.size = aEx.readSampleData(buf, 0); if (info.size < 0) break
                    info.offset = 0; info.presentationTimeUs = off + (t - base); info.flags = 0
                    mux.writeSampleData(at, buf, info); aEx.advance()
                }
                off += (lastV - base) + 33000L
            }
            mux.stop(); mux.release(); pfd.close(); vEx.release(); aEx.release()
            go(Intent(Intent.ACTION_VIEW).setDataAndType(dst, "video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
            return "Cortei ${(total - keptLen) / 1000000} segundos de silêncio: o vídeo foi de ${total / 1000000} para ${off / 1000000} segundos. Salvei em Filmes, pasta Jarvis. Os cortes seguem os quadros-chave, então alguns silêncios curtos podem sobrar."
        } catch (e: Exception) {
            try { out?.let { c.contentResolver.delete(it, null, null) } } catch (x: Exception) {}
            return "Não consegui editar o vídeo: ${e.message}"
        }
    }
    fun local7(l: String): String? {
        if (Regex("sil[êe]ncio").containsMatchIn(l) && Regex("v[ií]deo").containsMatchIn(l) && Regex("^(?:corta|tira|remove|edita|limpa|apaga|elimina)").containsMatchIn(l)) {
            val v = latestVideo() ?: return "Não achei vídeos. Aceite o acesso a vídeos nas permissões do Jarvis."
            return cutSilence(v)
        }
        return null
    }
    @Volatile var busy = false
    var rd = 0
    fun appNames(): String {
        val pm = c.packageManager
        return pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.loadLabel(pm).toString() }.distinct().sorted().take(150).joinToString(", ")
    }
    fun agent(goal: String): String {
        val j = cfg()
        if (j.optString("key").isEmpty() && (j.optJSONArray("provs")?.length() ?: 0) == 0 && j.optString("base").isEmpty()) return "Configure sua API Key nas configurações para eu ter cérebro."
        val mem = j.optJSONArray("mem")?.let { a -> (maxOf(0, a.length() - 60) until a.length()).joinToString("; ") { a.getString(it) } } ?: ""
        val les = j.optJSONArray("lessons")?.let { a -> (0 until a.length()).joinToString("; ") { a.getString(it) } } ?: ""
        val extra = if (Regex("notific|mensag|chegou|recebi|resumo|whatsapp|perdi|golpe|suspeit").containsMatchIn(goal.lowercase())) {
            val nn = synchronized(NotifService.recent) { NotifService.recent.takeLast(20) }
            "NOTIFICAÇÕES RECENTES: " + (if (nn.isEmpty()) "nenhuma (ou o acesso às notificações está desligado)" else nn.joinToString(" | "))
        } else ""
        val sys = "Você é ${j.optString("name", "Jarvis")}, assistente estilo Jarvis que controla o Android de ${j.optString("user").ifEmpty { "seu usuário" }}. " +
            "Personalidade: ${j.optString("pers")}. Memória do usuário: ${mem.ifEmpty { "nada ainda" }}. Agora: ${Date()}. Lições aprendidas: ${les.ifEmpty { "nenhuma" }}.\n" +
            "Responda SEMPRE apenas um JSON: {\"act\":\"...\",\"arg\":\"...\",\"say\":\"...\"}. Uma ação por vez. Ações: " +
            "open_app (arg=nome de um app instalado), click (arg=número [n] de um item da TELA ATUAL, ou o texto exato do botão), type (arg=texto a digitar no campo de texto), " +
            "enter (confirma/pesquisa no teclado), scroll_down, scroll_up, back, home, wait, tap (arg=x,y), swipe (arg=x1,y1,x2,y2), pc (arg=ação para o computador: open_url URL, open_app NOME, media playpause|next|prev, volume up|down, lock, ping), make_project (arg=descrição de um projeto com vários arquivos, salvo em zip), make_app (arg=descrição do mini app que o usuário quer; você mesmo cria e abre um app dentro do Jarvis, nunca sugira Play Store ou outras ferramentas), say (termina: fale em 'say', curto, natural para voz). " +
            "O usuário fala de forma natural e imprecisa: entenda a intenção e execute até concluir. Se for só conversa ou pergunta, use say direto. " +
            "Olhe a TELA ATUAL e as AÇÕES JÁ FEITAS; não repita o que falhou, tente outro caminho (ex.: ícone de busca, aba, botão). " +
            "Vídeo mais recente de um canal: pesquise o canal, abra-o, aba Vídeos (ordem recente) e abra o primeiro. " +
            "Se a acessibilidade estiver desligada, só consegue abrir apps: diga ao usuário para ativá-la. Ao concluir, use say confirmando. " +
            "Se aprender um fato durável sobre o usuário (nome, gostos, rotina, projetos, preferências), inclua também \"mem\":\"fato curto\" no JSON; nunca guarde senhas, dados bancários ou de saúde. " +
            "Se o usuário corrigir um erro seu (\"não, é o outro\", \"errado\"), inclua \"lesson\":\"o que fazer diferente, curto, citando app/tela\". " +
            "Para resumir, traduzir ou ler a página/tela, use o texto da TELA ATUAL (role para ver mais se precisar) e responda em say. Para resumo do dia use a hora, as NOTIFICAÇÕES e uma frase curta. " +
            "Se o pedido começar com [foto da câmera], uma foto da câmera está anexada: descreva ou responda sobre ela em say. Se perguntarem se algo é golpe, analise o texto ou link da tela ou das notificações (urgência, link estranho, pedido de dinheiro, código ou senha, remetente desconhecido), diga o risco (baixo, médio ou alto) e o que fazer. " +
            "Regras de toque: prefira click pelo número ou pelo texto exato; use tap e swipe só quando o elemento não aparece na lista (jogos, vídeo, editores, telas feitas de imagem), com as coordenadas da lista (@x,y) e o TAMANHO DA TELA. Depois de cada ação confira se a tela mudou como esperado; se não mudou, tente outro caminho em vez de repetir. " +
            "Antes de ações irreversíveis (enviar mensagem, pagar, comprar, apagar, desinstalar) pergunte antes usando say. " +
            "Não jogue partidas em tempo real nem controle jogos online competitivos: isso é trapaça e leva a banimento; explique isso e ofereça dicas ou análise de uma partida gravada. " +
            "Em editores de vídeo como CapCut, vá passo a passo pelas ferramentas visíveis (importar, cortar, legendas automáticas, velocidade) e confirme cada tela."
        val done = ArrayList<String>()
        val camImg = pendingImg; pendingImg = null
        for (n in 1..14) {
            if (cancel) return "Cancelado."
            val a = JarvisAccess.i
            val screen = a?.dump() ?: "(acessibilidade desligada: não vejo a tela)"
            val chat = hist.dropLast(1).takeLast(6).joinToString("\n") { "${it.first}: ${it.second}" }
            val user = "CONVERSA RECENTE:\n$chat\n\nPEDIDO: $goal\nAÇÕES JÁ FEITAS: ${done.joinToString(" | ").ifEmpty { "nenhuma" }}\n" +
                "APPS INSTALADOS: ${appNames()}\n$extra\nTAMANHO DA TELA: ${c.resources.displayMetrics.widthPixels}x${c.resources.displayMetrics.heightPixels}\nTELA ATUAL:\n$screen"
            val vis = a != null && (screen.lines().size < 8 || Regex("tela|vê |ver |olha|imagem|foto|descreve|o que é|o que tem|qual jogo|que jogo|que vídeo|golpe").containsMatchIn(goal.lowercase()))
            val raw = try { llm(sys, user, camImg ?: if (vis) a?.shot() else null) } catch (e: Exception) { return offlineMsg(e) }
            val o = try { JSONObject(raw.substring(raw.indexOf('{'), raw.lastIndexOf('}') + 1)) } catch (e: Exception) { return raw.take(300) }
            val act = o.optString("act"); val arg = o.optString("arg")
            o.optString("mem").takeIf { it.isNotBlank() }?.let { addMem(it) }
            o.optString("lesson").takeIf { it.isNotBlank() }?.let { addList("lessons", it, 60) }
            if (act == "say" || act == "done") return o.optString("say").ifEmpty { arg }.ifEmpty { "Pronto." }
            if (act == "make_app") return makeApp(arg)
            ev("step", "$act $arg"); sfx("act")
            val res = when (act) {
                "open_app" -> openApp(arg) ?: "app não encontrado"
                "click" -> acc { a2 -> arg.trim().toIntOrNull()?.let { n -> a2.clickIdx(n) } ?: a2.clickLabel(arg.trim()) }
                "tap" -> try { val q = arg.split(",").map { x -> x.trim().toFloat() }; acc { a2 -> if (a2.tapAt(q[0], q[1])) "tocou" else "falhou" } } catch (e: Exception) { "coordenadas inválidas" }
                "swipe" -> try { val q = arg.split(",").map { x -> x.trim().toFloat() }; acc { a2 -> a2.swipe(q[0], q[1], q[2], q[3]) } } catch (e: Exception) { "coordenadas inválidas" }
                "pc" -> pcAct(arg)
                "make_project" -> return makeProject(arg)
                "type" -> acc { it.type(arg) }
                "enter" -> acc { it.enter() }
                "scroll_down" -> acc { it.scroll(true) }
                "scroll_up" -> acc { it.scroll(false) }
                "back" -> acc { it.glob(AccessibilityService.GLOBAL_ACTION_BACK) }
                "home" -> acc { it.glob(AccessibilityService.GLOBAL_ACTION_HOME) }
                "wait" -> "ok"
                else -> "ação desconhecida"
            }
            done.add("$act $arg -> $res")
            settle(if (act == "open_app") 2500L else 900L)
        }
        return "Fiz o que consegui, mas não consegui terminar. Me diga o próximo passo."
    }
    fun gkey(): String {
        val j = cfg(); var k = if (j.optString("prov", "gemini") == "gemini") j.optString("key") else ""
        if (k.isEmpty()) j.optJSONArray("provs")?.let { a -> for (i in 0 until a.length()) { val p = a.getJSONObject(i); if (p.optString("t") == "gemini" && k.isEmpty()) k = p.optString("k") } }
        return k
    }
    fun style(): String {
        val hr = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return if (hr in 0..5) "Sussurre com voz grave e calma, bem baixinho, como uma IA leal" else "Diga com voz grave, calma, elegante e levemente britânica, como uma IA sofisticada e leal"
    }
    fun addList(k: String, f: String, cap: Int) {
        val j = cfg(); val a = j.optJSONArray(k) ?: JSONArray()
        for (i in 0 until a.length()) if (a.getString(i).equals(f, true)) return
        if (a.length() >= cap) a.remove(0)
        a.put(f.take(200)); j.put(k, a); save(j.toString())
    }
    fun logLine(u: String, r: String) {
        try {
            val f = File(c.filesDir, "log.txt"); if (f.exists() && f.length() > 1000000) f.renameTo(File(c.filesDir, "log_${System.currentTimeMillis()}.txt"))
            f.appendText("${java.text.SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date())} | eu: ${u.take(300)} | jarvis: ${r.take(300).replace("\n", " ")}\n")
        } catch (e: Exception) {}
    }
    fun takeWake(): String? {
        val j = cfg(); if (j.optLong("sleep", 0) == 0L) return null
        val d = j.optString("dream"); j.put("sleep", 0); j.put("dream", ""); save(j.toString()); return d
    }
    fun nextAt(hh: Int, mm: Int): Long {
        val cal = Calendar.getInstance(); cal.set(Calendar.HOUR_OF_DAY, hh); cal.set(Calendar.MINUTE, mm); cal.set(Calendar.SECOND, 0)
        if (cal.timeInMillis <= System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR, 1)
        return cal.timeInMillis
    }
    fun armAt(id: String, t: Long) {
        val pi = PendingIntent.getBroadcast(c, id.hashCode(), Intent(c, AlarmRx::class.java).putExtra("id", id), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)
    }
    fun arm(o: JSONObject) = armAt(o.getString("id"), nextAt(o.getInt("h"), o.getInt("m")))
    fun rescheduleAll() {
        val a = cfg().optJSONArray("sched") ?: return
        for (i in 0 until a.length()) arm(a.getJSONObject(i))
        if (cfg().optLong("sleep", 0) > 0) armAt("dream", nextAt(3, 30))
        cfg().optJSONArray("letters")?.let { ls -> for (i in 0 until ls.length()) { val o = ls.getJSONObject(i); if (o.getLong("t") > System.currentTimeMillis()) armAt(o.getString("id"), o.getLong("t")) } }
    }
    fun fire(id: String) {
        if (id == "dream") { dream(); return }
        if (id.startsWith("L")) {
            val ls = cfg().optJSONArray("letters")
            if (ls != null) for (i in 0 until ls.length()) { val o = ls.getJSONObject(i); if (o.getString("id") == id) {
                val txt = "Carta do passado, de ${java.text.SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR")).format(Date(o.getLong("from")))}: ${o.getString("txt")}"
                h.postDelayed({ ev("reply", txt); speak(txt) }, 2500) } }
            return
        }
        val a = cfg().optJSONArray("sched") ?: return
        for (i in 0 until a.length()) { val o = a.getJSONObject(i); if (o.getString("id") == id) { arm(o); h.postDelayed({ ask(o.getString("cmd")) }, 2500) } }
    }
    fun dream() {
        if (cfg().optLong("sleep", 0) == 0L) return
        Thread {
            try {
                val f = File(c.filesDir, "log.txt"); val log = if (f.exists()) f.readLines().takeLast(60).joinToString("\n") else ""
                val mem = cfg().optJSONArray("mem")?.toString() ?: "[]"
                val raw = llm("Você é o Jarvis sonhando à noite. Responda só JSON {\"say\":\"...\"}.", "Memória: $mem\nConversas recentes:\n$log\n\nCrie UMA ideia ou conexão útil e criativa sobre os projetos do usuário, em até 3 frases faladas, em português.", null)
                setCfg("dream", JSONObject(raw.substring(raw.indexOf('{'), raw.lastIndexOf('}') + 1)).optString("say"))
            } catch (e: Exception) {}
        }.start()
    }
    fun web(q: String): String {
        val key = gkey(); if (key.isEmpty()) return "Preciso de uma chave do Gemini para pesquisar na web."
        val body = JSONObject().put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", "Responda em português, em até 3 frases curtas, naturais para serem faladas, com dados atuais. Sem markdown."))))
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", q)))))
            .put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
        return try {
            val o = JSONObject(String(post("https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent?key=$key", body.toString()).second))
            if (o.has("error")) "Erro na pesquisa: " + o.getJSONObject("error").optString("message")
            else o.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
        } catch (e: Exception) { "Falha na pesquisa: ${e.message}" }
    }
    fun saveRt(n: String, s: String): String {
        val st = JSONArray(); s.split(Regex(";|,| e depois | então | e ")).map { it.trim() }.filter { it.length > 2 }.forEach { st.put(it) }
        if (st.length() == 0) return "Não entendi os passos."
        val j = cfg(); val r = j.optJSONObject("routines") ?: JSONObject(); r.put(n.trim().lowercase(), st); j.put("routines", r); save(j.toString())
        return "Rotina ${n.trim()} salva com ${st.length()} passos."
    }
    fun local2(l: String): String? {
        val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        fun key(k: Int) { am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, k)); am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, k)) }
        val rt = cfg().optJSONObject("routines") ?: JSONObject()
        for (k in rt.keys()) if (l == k || l.removePrefix("ativa ").removePrefix("ativar ").removePrefix("executa ") == k) {
            if (rd >= 2) return "Rotina dentro de rotina demais."
            val st = rt.getJSONArray(k)
            rd++
            try { for (i in 0 until st.length()) { if (cancel) break; val s = st.getString(i); ev("step", s); local(s) ?: agent(s); Thread.sleep(800) } } finally { rd-- }
            return "Rotina $k concluída."
        }
        Regex("^(?:cria|crie|ensina|ensine|aprende)(?:r)? (?:uma )?(?:rotina|comando) (?:chamad[ao] )?(.+?)(?:: | que | para )(.+)$").find(l)?.let { return saveRt(it.groupValues[1], it.groupValues[2]) }
        Regex("^quando eu (?:falar|disser) (.+?)(?:, | então | aí | faz | fazer |: )(?:você |tu )?(.+)$").find(l)?.let { return saveRt(it.groupValues[1].trim('"', '\''), it.groupValues[2]) }
        if (Regex("quais.*rotinas").containsMatchIn(l)) { val n = rt.keys().asSequence().toList(); return if (n.isEmpty()) "Você ainda não tem rotinas." else "Suas rotinas: " + n.joinToString(", ") + "." }
        Regex("^(?:apaga|apague|esquece|remove) (?:a )?rotina (.+)$").find(l)?.let { val j = cfg(); val r = j.optJSONObject("routines") ?: JSONObject(); r.remove(it.groupValues[1].trim()); j.put("routines", r); save(j.toString()); return "Rotina apagada." }
        Regex("^(?:todo dia|todos os dias),? (?:às|as) (\\d{1,2})(?:h|:|\\s?horas?)?(\\d{2})? (.+)$").find(l)?.let {
            val hh = it.groupValues[1].toInt(); val mm = it.groupValues[2].toIntOrNull() ?: 0
            if (hh > 23) return "Hora inválida."
            val j = cfg(); val a = j.optJSONArray("sched") ?: JSONArray()
            val o = JSONObject().put("id", "s" + System.currentTimeMillis()).put("h", hh).put("m", mm).put("cmd", it.groupValues[3])
            a.put(o); j.put("sched", a); save(j.toString()); arm(o)
            return "Combinado. Todo dia às $hh:${"%02d".format(mm)} eu faço: ${it.groupValues[3]}."
        }
        if (Regex("(?:cancela|apaga|remove).*(?:agendad|agendamento)").containsMatchIn(l)) { setCfg("sched", JSONArray()); return "Tarefas agendadas apagadas." }
        if (Regex("^(?:jarvis,? )?(?:dormi|dorme|vou dormir|modo sono|modo sonho|boa noite)").containsMatchIn(l)) {
            setCfg("sleep", System.currentTimeMillis()); setCfg("dream", ""); armAt("dream", nextAt(3, 30))
            return "Boa noite. Vou sonhar com os seus projetos. Quando você falar comigo de novo, eu acordo na hora."
        }
        if (Regex("alguém (?:tá|está|esta) vindo|disfarça|esconde a tela|modo disfarce").containsMatchIn(l)) { openApp("calculadora") ?: openApp("notas"); return "." }
        if (l.startsWith("resumo do dia") || l.contains("meu resumo do dia")) return agent("Faça meu resumo do dia: diga a data e a hora, resuma minhas notificações recentes e termine com uma frase motivadora curta.")
        Regex("(?:o que|que) (?:eu )?(?:te |lhe )?(?:falei|disse|contei|conversamos) (?:sobre |da |do |de )?(.+)").find(l)?.let {
            val ks = it.groupValues[1].split(" ").filter { w -> w.length > 3 }
            val fs = c.filesDir.listFiles { x -> x.name.startsWith("log") && x.name.endsWith(".txt") }?.sortedBy { x -> x.name } ?: listOf()
            val hits = if (ks.isNotEmpty()) fs.flatMap { x -> x.readLines() }.filter { ln -> ks.any { k -> ln.lowercase().contains(k) } }.takeLast(12) else listOf()
            return agent("O usuário pergunta o que falou sobre \"${it.groupValues[1]}\". Trechos do histórico:\n${hits.joinToString("\n").ifEmpty { "(nada encontrado)" }}\nResponda só com base neles e diga se não achou.")
        }
        Regex("^(?:pesquis[ae]|busca|procura)(?: na web| na internet| no google)? (?:sobre |por )?(.+)$").find(l)?.let { if (!Regex("youtube|tiktok|instagram|spotify|whatsapp|loja|app").containsMatchIn(l)) return web(it.groupValues[1]) }
        if (Regex("^(?:me (?:diz|fala|conta) )?(?:as )?(?:notícias|noticias|o que saiu|o que aconteceu|previsão do tempo|cotação|quanto está o)").containsMatchIn(l)) return web(l)
        if (Regex("^(?:pausa|pausar|para) (?:a |o )?(?:música|musica|vídeo|video)").containsMatchIn(l)) { key(KeyEvent.KEYCODE_MEDIA_PAUSE); return "Pausado." }
        if (Regex("^(?:toca|continua|retoma|dá play|da play|play)(?: a música| a musica)?$").containsMatchIn(l)) { key(KeyEvent.KEYCODE_MEDIA_PLAY); return "Tocando." }
        if (Regex("^(?:próxima|proxima|pula|passa)(?: a)?(?: música| musica| faixa)?$").containsMatchIn(l)) { key(KeyEvent.KEYCODE_MEDIA_NEXT); return "Próxima." }
        if (Regex("^(?:anterior|volta a música|volta a musica|música anterior)$").containsMatchIn(l)) { key(KeyEvent.KEYCODE_MEDIA_PREVIOUS); return "Anterior." }
        Regex("volume (?:em |para |no |a )?(\\d{1,3})").find(l)?.let {
            val mx = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            am.setStreamVolume(AudioManager.STREAM_MUSIC, it.groupValues[1].toInt().coerceIn(0, 100) * mx / 100, AudioManager.FLAG_SHOW_UI)
            return "Volume em ${it.groupValues[1]} por cento."
        }
        if (Regex("^(?:aumenta|sobe) (?:o )?volume").containsMatchIn(l)) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI); return "Ok." }
        if (Regex("^(?:diminui|abaixa) (?:o )?volume").containsMatchIn(l)) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI); return "Ok." }
        Regex("^(liga|ligar|acende|acender|apaga|apagar|desliga|desligar)(?: a)? lanterna").find(l)?.let {
            val on = it.groupValues[1].startsWith("lig") || it.groupValues[1].startsWith("acen")
            try { val cm = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager; cm.setTorchMode(cm.cameraIdList[0], on); return if (on) "Lanterna ligada." else "Lanterna desligada." }
            catch (e: Exception) { return "Não consegui usar a lanterna." }
        }
        Regex("^(?:timer|cronômetro|cronometro|temporizador) (?:de |para )?(\\d+) (minuto|segundo|hora)").find(l)?.let {
            val n = it.groupValues[1].toInt() * when (it.groupValues[2]) { "hora" -> 3600; "minuto" -> 60; else -> 1 }
            go(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, n).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            return "Timer de ${it.groupValues[1]} ${it.groupValues[2]}s ligado."
        }
        Regex("^(?:alarme|despertador) (?:para |às |as )?(\\d{1,2})(?:h|:|\\s?horas?)?(\\d{2})?").find(l)?.let {
            go(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, it.groupValues[1].toInt()).putExtra(AlarmClock.EXTRA_MINUTES, it.groupValues[2].toIntOrNull() ?: 0).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            return "Alarme criado."
        }
        return null
    }
    fun resolve(p: JSONObject): Triple<String, String, String> {
        val k = p.optString("k"); val t = p.optString("t", "auto"); val b = p.optString("b").trim().trimEnd('/')
        val m = p.optString("m").trim(); val lm = m.lowercase()
        var type: String; var base = b
        if (t == "gemini" || t == "anthropic" || t == "custom") type = t
        else if (b.contains("generativelanguage")) type = "gemini"
        else if (b.contains("anthropic.com")) type = "anthropic"
        else if (b.isNotEmpty()) type = "openai"
        else if (k.startsWith("AIza") || lm.startsWith("gemini")) type = "gemini"
        else if (k.startsWith("sk-ant") || lm.startsWith("claude")) type = "anthropic"
        else {
            type = "openai"
            base = when {
                lm.contains(":") -> "https://ollama.com/v1"
                k.startsWith("freellmapi-") -> "http://127.0.0.1:3001/v1"
                k.startsWith("sk-or-") -> "https://openrouter.ai/api/v1"
                k.startsWith("gsk_") -> "https://api.groq.com/openai/v1"
                k.startsWith("xai-") -> "https://api.x.ai/v1"
                k.startsWith("pplx-") -> "https://api.perplexity.ai"
                lm.contains("deepseek") -> "https://api.deepseek.com/v1"
                lm.contains("mistral") -> "https://api.mistral.ai/v1"
                else -> "https://api.openai.com/v1"
            }
        }
        if (type == "openai" && base.isEmpty()) base = "https://api.openai.com/v1"
        if (base.contains("ollama.com") && !base.endsWith("/v1")) base = base.trimEnd('/') + "/v1"
        val model = m.ifEmpty {
            when {
                type == "gemini" -> "gemini-flash-latest"
                type == "anthropic" -> "claude-haiku-5-5"
                base.contains(":3001") -> "auto"
                base.contains("ollama.com") -> "gpt-oss:120b"
                base.contains("groq") -> "llama-3.3-70b-versatile"
                base.contains("openrouter") -> "openrouter/auto"
                base.contains("deepseek") -> "deepseek-chat"
                base.contains("mistral") -> "mistral-small-latest"
                base.contains("x.ai") -> "grok-4"
                base.contains("perplexity") -> "sonar"
                else -> "gpt-4o-mini"
            }
        }
        return Triple(type, base, if (base.contains("ollama.com")) model.removeSuffix("-cloud") else model)
    }
    fun oai(base0: String, key: String, model: String, ms: JSONArray): String {
        val body = JSONObject().put("model", model).put("messages", ms).toString()
        var base = base0
        for (att in 0..1) {
            val raw = String(post("$base/chat/completions", body, (if (key.isEmpty()) mapOf<String, String>() else mapOf("Authorization" to "Bearer $key"))).second)
            if (raw.trimStart().startsWith("{")) {
                val o = JSONObject(raw)
                if (o.has("error")) { val e = o.opt("error"); throw Exception(if (e is JSONObject) e.optString("message") else e.toString()) }
                return o.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
            }
            if (att == 0 && !base.endsWith("/v1")) { base = base.trimEnd('/') + "/v1"; continue }
            throw Exception("o servidor devolveu uma página e não uma resposta de IA. Confira a URL base (a Ollama Cloud usa https://ollama.com/v1).")
        }
        throw Exception("sem resposta")
    }
    fun claude(base: String, key: String, model: String, sys: String, user: String, img: String?): String {
        val b = base.ifEmpty { "https://api.anthropic.com" }.removeSuffix("/v1")
        val content = JSONArray()
        if (img != null) for (im in img.split("|")) content.put(JSONObject().put("type", "image").put("source", JSONObject().put("type", "base64").put("media_type", "image/jpeg").put("data", im)))
        content.put(JSONObject().put("type", "text").put("text", user))
        val body = JSONObject().put("model", model).put("max_tokens", 1024).put("system", sys).put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))
        val o = JSONObject(String(post("$b/v1/messages", body.toString(), mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01")).second))
        if (o.has("error")) throw Exception(o.getJSONObject("error").optString("message"))
        return o.getJSONArray("content").getJSONObject(0).getString("text")
    }
    fun vapi(j: JSONObject, text: String): File? {
        val v = j.optJSONObject("vapi") ?: return null
        val key = v.optString("key"); val type = v.optString("type"); val voice = v.optString("voice"); val model = v.optString("model")
        var url = ""; var body = ""; var resp = "audio"; val hd = HashMap<String, String>()
        if (type == "openai") {
            if (key.isEmpty()) return null
            url = v.optString("url").ifEmpty { "https://api.openai.com/v1/audio/speech" }; hd["Authorization"] = "Bearer $key"
            body = JSONObject().put("model", model.ifEmpty { "tts-1" }).put("input", text).put("voice", voice.ifEmpty { "onyx" }).put("response_format", "mp3").toString()
        } else {
            url = v.optString("url").replace("{KEY}", key).replace("{VOICE}", voice); if (url.isEmpty()) return null
            v.optString("headers").lines().forEach { ln -> val i = ln.indexOf(':'); if (i > 0) hd[ln.substring(0, i).trim()] = ln.substring(i + 1).trim().replace("{KEY}", key) }
            val q = JSONObject.quote(text).let { it.substring(1, it.length - 1) }
            body = v.optString("body").replace("{TEXT}", q).replace("{VOICE}", voice).replace("{MODEL}", model).replace("{KEY}", key)
            resp = v.optString("resp").ifEmpty { "audio" }
        }
        val (code, b) = post(url, body, hd)
        if (code >= 300) return null
        var bytes = b
        if (resp.startsWith("json:")) {
            var o: Any = JSONObject(String(b))
            for (seg in resp.removePrefix("json:").split(".")) { val cur = o; o = if (cur is JSONArray) cur.get(seg.toInt()) else (cur as JSONObject).get(seg) }
            bytes = Base64.decode(o.toString(), Base64.DEFAULT)
        }
        val f = File(c.cacheDir, "v.mp3"); f.writeBytes(bytes); return f
    }
    fun speak(t: String) {
        stopAudio()
        Thread {
            val j = cfg(); val clean = t.replace(Regex("[*_`#]"), "")
            try { val f = vapi(j, clean); if (f != null) { h.post { play(f) }; return@Thread } } catch (e: Exception) {}
            val k = j.optString("vkey")
            if (k.isNotEmpty()) try {
                val id = j.optString("vid").ifEmpty { "pNInz6obpgDQGcFmaJgB" }
                val body = JSONObject().put("text", clean).put("model_id", "eleven_multilingual_v2").toString()
                val (code, b) = post("https://api.elevenlabs.io/v1/text-to-speech/$id", body, mapOf("xi-api-key" to k))
                if (code < 300) { val f = File(c.cacheDir, "v.mp3"); f.writeBytes(b); h.post { play(f) }; return@Thread }
            } catch (e: Exception) {}
            try { if (gtts(t)) return@Thread } catch (e: Exception) {}
            h.post { deep(t) }
        }.start()
    }
    fun pscreen(): Boolean = cfg().optBoolean("pscreen", false)
    fun appsDir(): File { val d = File(c.filesDir, "apps"); d.mkdirs(); return d }
    fun openMini(n: String) { go(Intent(c, AppView::class.java).putExtra("p", File(appsDir(), "$n.html").path)) }
    fun makeApp(desc: String): String = try {
        val raw = llm("Você cria mini apps. Responda só JSON {\"name\":\"nome curto sem espaços\",\"html\":\"página HTML única e completa, com CSS e JS embutidos, visual escuro e bonito, funciona offline, salva dados com localStorage\"}.", "Crie um app: $desc", null)
        val o = JSONObject(raw.substring(raw.indexOf('{'), raw.lastIndexOf('}') + 1))
        val n = o.getString("name").lowercase().replace(Regex("[^a-z0-9-]"), "-").take(30)
        File(appsDir(), "$n.html").writeText(o.getString("html"))
        openMini(n); "Pronto! Criei o app $n e já abri. Para abrir de novo, diga: abre o mini app $n."
    } catch (e: Exception) { "Não consegui criar o app: ${e.message}" }
    fun local3(l: String): String? {
        if (!Regex("^(?:como|por que|porque|o que|qual|quais|me explica|me ensina|você sabe|voce sabe)").containsMatchIn(l)) Regex("(?:cria|crie|criar|faz|fazer|faça|monta|montar|gera|gerar) (?:pra mim |para mim |um |uma )*(?:mini )?(?:app|aplicativo|ferramenta) (?:de |para |que |pra |do |da )?(.+)$").find(l)?.let { return makeApp(it.groupValues[1]) }
        Regex("^(?:abre|abrir) (?:o )?mini app (.+)$").find(l)?.let { val n = it.groupValues[1].trim().replace(" ", "-"); return if (File(appsDir(), "$n.html").exists()) { openMini(n); "Abrindo $n." } else "Não achei esse mini app." }
        if (Regex("meus mini apps|quais mini apps").containsMatchIn(l)) { val n = appsDir().list()?.map { it.removeSuffix(".html") } ?: listOf(); return if (n.isEmpty()) "Você ainda não criou mini apps." else "Seus mini apps: " + n.joinToString(", ") + "." }
        Regex("^(?:me lembra|lembra|guarda)(?: disso)? daqui a (\\d+) (dias?|semanas?|mes(?:es)?|mês|anos?),? (.+)$").find(l)?.let {
            val n = it.groupValues[1].toInt(); val u = it.groupValues[2]; val cal = Calendar.getInstance()
            when { u.startsWith("dia") -> cal.add(Calendar.DAY_OF_YEAR, n); u.startsWith("sem") -> cal.add(Calendar.DAY_OF_YEAR, 7 * n); u.startsWith("m") -> cal.add(Calendar.MONTH, n); else -> cal.add(Calendar.YEAR, n) }
            val id = "L" + System.currentTimeMillis(); val j = cfg(); val a = j.optJSONArray("letters") ?: JSONArray()
            a.put(JSONObject().put("id", id).put("t", cal.timeInMillis).put("txt", it.groupValues[3]).put("from", System.currentTimeMillis())); j.put("letters", a); save(j.toString()); armAt(id, cal.timeInMillis)
            return "Guardado. Eu te entrego isso em ${java.text.SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR")).format(cal.time)}."
        }
        if (Regex("^(?:ativa|liga|ativar) (?:a )?memória da tela").containsMatchIn(l)) { setCfg("pscreen", true); return "Memória da tela ativada. Guardo só o texto, só no seu celular. Para apagar tudo, diga: esquece a tela." }
        if (Regex("^(?:desativa|desliga|desativar) (?:a )?memória da tela").containsMatchIn(l)) { setCfg("pscreen", false); return "Memória da tela desligada." }
        if (Regex("^(?:esquece|apaga) (?:a )?(?:tela|memória da tela)").containsMatchIn(l)) { File(c.filesDir, "screen.txt").delete(); return "Apaguei tudo que eu guardava da sua tela." }
        Regex("(?:o que|qual|que).* (?:eu )?(?:vi|estava vendo|li) (?:sobre |de |da |do )?(.+)").find(l)?.let {
            val ks = it.groupValues[1].split(" ").filter { w -> w.length > 3 }; val f = File(c.filesDir, "screen.txt")
            val hits = if (f.exists() && ks.isNotEmpty()) f.readLines().filter { ln -> ks.any { k -> ln.lowercase().contains(k) } }.takeLast(10) else listOf()
            return agent("O usuário pergunta o que viu sobre \"${it.groupValues[1]}\". Trechos do que apareceu na tela dele:\n${hits.joinToString("\n").ifEmpty { "(nada encontrado; a memória da tela pode estar desligada)" }}\nResponda só com base neles e diga se não achou.")
        }
        return null
    }
    @Volatile var pendingImg: String? = null
    var ctxReg = false; var lastCtx = 0L; var regAt = 0L
    fun dev(): JSONObject = cfg().optJSONObject("devices") ?: JSONObject()
    fun httpCall(spec: String, hd: JSONObject? = null): String = try {
        val ps = spec.trim().split(" ", limit = 3)
        val isM = ps[0].uppercase() in listOf("GET", "POST", "PUT")
        val m = if (isM) ps[0].uppercase() else "GET"; val u = if (isM) ps[1] else ps[0]; val body = if (isM) ps.getOrElse(2) { "" } else ""
        val k = URL(u).openConnection() as HttpURLConnection
        k.requestMethod = m; k.connectTimeout = 6000; k.readTimeout = 6000
        hd?.keys()?.forEach { x -> k.setRequestProperty(x, hd.getString(x)) }
        if (body.isNotEmpty()) { k.doOutput = true; k.setRequestProperty("Content-Type", "application/json"); k.outputStream.use { it.write(body.toByteArray()) } }
        "ok ${k.responseCode}"
    } catch (e: Exception) { "falhou: ${e.message}" }
    fun ctxFire(k: String) {
        val cmd = cfg().optJSONObject("ctx")?.optString(k) ?: return
        val now = System.currentTimeMillis()
        if (cmd.isEmpty() || now - lastCtx < 30000 || now - regAt < 8000) return
        lastCtx = now; h.postDelayed({ ask(cmd) }, 1500)
    }
    fun regCtx() {
        if (ctxReg) return
        ctxReg = true; regAt = System.currentTimeMillis()
        c.registerReceiver(object : BroadcastReceiver() {
            override fun onReceive(x: Context?, i: Intent?) { ctxFire(if (i?.action == Intent.ACTION_POWER_CONNECTED) "charge_on" else "charge_off") }
        }, IntentFilter().apply { addAction(Intent.ACTION_POWER_CONNECTED); addAction(Intent.ACTION_POWER_DISCONNECTED) })
        try {
            (c.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager).registerNetworkCallback(
                NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI).build(),
                object : ConnectivityManager.NetworkCallback() { override fun onAvailable(n: Network) { ctxFire("wifi_on") } })
        } catch (e: Exception) {}
    }
    fun faxina(): String {
        val st = android.os.StatFs(android.os.Environment.getDataDirectory().path)
        val head = "Livre: %.1f de %.1f GB.".format(st.availableBytes / 1073741824.0, st.totalBytes / 1073741824.0)
        val um = c.getSystemService(Context.USAGE_STATS_SERVICE) as android.app.usage.UsageStatsManager
        val now = System.currentTimeMillis()
        val us = um.queryUsageStats(android.app.usage.UsageStatsManager.INTERVAL_DAILY, now - 60L * 86400000, now)
        if (us.isNullOrEmpty()) return "$head Para achar apps sem uso, ative o acesso ao uso de apps em ⚙."
        val last = HashMap<String, Long>(); us.forEach { if (it.lastTimeUsed > (last[it.packageName] ?: 0L)) last[it.packageName] = it.lastTimeUsed }
        val pm = c.packageManager
        val unused = pm.getInstalledApplications(0).filter {
            (it.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM) == 0 && pm.getLaunchIntentForPackage(it.packageName) != null &&
                it.packageName != c.packageName && (last[it.packageName] ?: 0L) < now - 30L * 86400000
        }.map { pm.getApplicationLabel(it).toString() }.take(12)
        return head + " Apps sem uso há mais de 30 dias: " + (if (unused.isEmpty()) "nenhum" else unused.joinToString(", ")) + ". Diga: desinstala e o nome do app, e eu abro a tela de confirmação."
    }
    fun local4(l: String, t: String): String? {
        if (Regex("câmera|camera").containsMatchIn(l) && Regex("olha|olhe|veja|analisa|identifica|traduz|descreve|pela câmera|pela camera|usa a câmera|usa a camera|o que é").containsMatchIn(l)) {
            go(Intent(c, CamActivity::class.java).putExtra("q", t)); return "Abrindo a câmera. Tire a foto e eu respondo."
        }
        Regex("^quando eu (ligar|conectar|desligar|tirar) (?:o |a )?(carregador|wi-?fi)(?:,| então| aí)? (.+)$").find(l)?.let {
            val a = it.groupValues[1]
            val k = if (it.groupValues[2].startsWith("carreg")) (if (a == "ligar" || a == "conectar") "charge_on" else "charge_off") else "wifi_on"
            val j = cfg(); val x = j.optJSONObject("ctx") ?: JSONObject(); x.put(k, it.groupValues[3]); j.put("ctx", x); save(j.toString())
            return "Combinado. Quando isso acontecer eu faço: ${it.groupValues[3]}."
        }
        if (l.contains("faxina")) return faxina()
        Regex("^(?:desinstala|desinstalar) (?:o |a )?(?:app |aplicativo )?(.+)$").find(l)?.let {
            val pm = c.packageManager; val n = it.groupValues[1].trim()
            val app = pm.getInstalledApplications(0).firstOrNull { a -> (a.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM) == 0 && pm.getApplicationLabel(a).toString().lowercase().contains(n) }
            return if (app == null) "Não achei esse app." else { go(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.packageName}"))); "Abri a tela de desinstalação. Você confirma lá." }
        }
        Regex("^(?:cadastra|cadastre|registra|adiciona)(?:r)? (?:o |a )?(?:dispositivo|aparelho) (.+?),? liga (\\S+?),? desliga (\\S+)$", RegexOption.IGNORE_CASE).find(t.trim())?.let {
            val j = cfg(); val d = j.optJSONObject("devices") ?: JSONObject()
            d.put(it.groupValues[1].trim().lowercase(), JSONObject().put("on", it.groupValues[2]).put("off", it.groupValues[3])); j.put("devices", d); save(j.toString())
            return "Dispositivo ${it.groupValues[1].trim()} salvo."
        }
        if (Regex("meus dispositivos|quais dispositivos").containsMatchIn(l)) { val n = dev().keys().asSequence().toList(); return if (n.isEmpty()) "Nenhum dispositivo cadastrado." else "Dispositivos: " + n.joinToString(", ") + "." }
        Regex("^(liga|ligar|acende|acender|desliga|desligar|apaga|apagar) (?:a |o |as |os )?(.+)$").find(l)?.let {
            val on = it.groupValues[1].startsWith("lig") || it.groupValues[1].startsWith("acen"); val n = it.groupValues[2].trim()
            val d = dev(); val k = d.keys().asSequence().firstOrNull { x -> n.contains(x) } ?: return@let
            val r = httpCall(d.getJSONObject(k).getString(if (on) "on" else "off"), d.getJSONObject(k).optJSONObject("headers"))
            return if (r.startsWith("ok")) (if (on) "$k ligado." else "$k desligado.") else "$k: $r"
        }
        return null
    }
    var wave = 0L; var waves = 0; var proxReg = false
    fun regProx() {
        if (proxReg) return
        proxReg = true
        val sm = c.getSystemService(Context.SENSOR_SERVICE) as android.hardware.SensorManager
        val s = sm.getDefaultSensor(android.hardware.Sensor.TYPE_PROXIMITY) ?: return
        sm.registerListener(object : android.hardware.SensorEventListener {
            var near = false
            override fun onSensorChanged(e: android.hardware.SensorEvent) {
                if (!cfg().optBoolean("aceno", false)) return
                val n = e.values[0] < s.maximumRange
                if (n && !near) {
                    val now = System.currentTimeMillis(); waves = if (now - wave < 1200) waves + 1 else 1; wave = now
                    if (waves >= 2) { waves = 0; if (mode == "idle") listen { ask(it) } else stopSpeak() }
                }
                near = n
            }
            override fun onAccuracyChanged(x: android.hardware.Sensor?, a: Int) {}
        }, s, android.hardware.SensorManager.SENSOR_DELAY_NORMAL)
    }
    fun recentImages(n: Int): List<Uri> {
        val out = ArrayList<Uri>(); val base = android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        try {
            c.contentResolver.query(base, arrayOf(android.provider.MediaStore.Images.Media._ID), null, null, "${android.provider.MediaStore.Images.Media.DATE_ADDED} DESC")?.use { cu ->
                while (cu.moveToNext() && out.size < n) out.add(android.content.ContentUris.withAppendedId(base, cu.getLong(0)))
            }
        } catch (e: Exception) {}
        return out
    }
    fun thumb(u: Uri, px: Int): String? = try {
        val bm = c.contentResolver.loadThumbnail(u, android.util.Size(px, px), null)
        val o = java.io.ByteArrayOutputStream(); bm.compress(android.graphics.Bitmap.CompressFormat.JPEG, 60, o)
        Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
    } catch (e: Exception) { null }
    fun galeria(desc: String): String {
        val imgs = recentImages(48)
        if (imgs.isEmpty()) return "Não consegui ver suas fotos. Aceite o acesso às fotos nas permissões do Jarvis."
        val hits = ArrayList<Uri>()
        for (b in imgs.chunked(12)) {
            if (cancel) break
            val th = b.mapNotNull { thumb(it, 256) }; if (th.size != b.size) continue
            val raw = try {
                llm("Você procura fotos. Responda só JSON {\"match\":[números]}.", "As ${b.size} imagens anexas estão numeradas de 0 a ${b.size - 1} na ordem. Quais combinam com: $desc ? Se nenhuma, match vazio.", th.joinToString("|"))
            } catch (e: Exception) { return "Falha na busca: ${e.message}" }
            try { val m = JSONObject(raw.substring(raw.indexOf('{'), raw.lastIndexOf('}') + 1)).getJSONArray("match"); for (i in 0 until m.length()) hits.add(b[m.getInt(i)]) } catch (e: Exception) {}
        }
        if (hits.isEmpty()) return "Não achei nas suas últimas ${imgs.size} fotos."
        go(Intent(Intent.ACTION_VIEW).setDataAndType(hits[0], "image/*").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        return "Achei ${hits.size}. Abri a primeira."
    }
    fun editFoto(l: String): String {
        val u = recentImages(1).firstOrNull() ?: return "Não achei fotos. Aceite o acesso às fotos nas permissões do Jarvis."
        val bm = (try { c.contentResolver.openInputStream(u).use { android.graphics.BitmapFactory.decodeStream(it, null, android.graphics.BitmapFactory.Options().apply { inSampleSize = 2 }) } } catch (e: Exception) { null }) ?: return "Não consegui abrir a foto."
        val cm = android.graphics.ColorMatrix(); var rot = 0f; var crop = ""
        fun add(v: Float) = cm.set(floatArrayOf(1f, 0f, 0f, 0f, v, 0f, 1f, 0f, 0f, v, 0f, 0f, 1f, 0f, v, 0f, 0f, 0f, 1f, 0f))
        when {
            Regex("mais clara|clareia|ilumina").containsMatchIn(l) -> add(40f)
            Regex("escurece|mais escura").containsMatchIn(l) -> add(-40f)
            l.contains("contraste") -> cm.set(floatArrayOf(1.3f, 0f, 0f, 0f, -30f, 0f, 1.3f, 0f, 0f, -30f, 0f, 0f, 1.3f, 0f, -30f, 0f, 0f, 0f, 1f, 0f))
            l.contains("preto e branco") -> cm.setSaturation(0f)
            Regex("gira|rotaciona").containsMatchIn(l) -> rot = 90f
            Regex("vertical|9:16").containsMatchIn(l) -> crop = "v"
            l.contains("quadrad") -> crop = "q"
            else -> return "Diga o que fazer: mais clara, mais escura, mais contraste, preto e branco, girar, recortar vertical ou quadrada."
        }
        var src = bm
        if (crop == "v") { val w = Math.min(bm.width, (bm.height * 9f / 16f).toInt()); src = android.graphics.Bitmap.createBitmap(bm, (bm.width - w) / 2, 0, w, bm.height) }
        if (crop == "q") { val s = Math.min(bm.width, bm.height); src = android.graphics.Bitmap.createBitmap(bm, (bm.width - s) / 2, (bm.height - s) / 2, s, s) }
        val out = android.graphics.Bitmap.createBitmap(src.width, src.height, android.graphics.Bitmap.Config.ARGB_8888)
        val p = android.graphics.Paint(); p.colorFilter = android.graphics.ColorMatrixColorFilter(cm)
        android.graphics.Canvas(out).drawBitmap(src, 0f, 0f, p)
        val res = if (rot != 0f) android.graphics.Bitmap.createBitmap(out, 0, 0, out.width, out.height, android.graphics.Matrix().apply { postRotate(rot) }, true) else out
        val v = android.content.ContentValues().apply { put(android.provider.MediaStore.Images.Media.DISPLAY_NAME, "jarvis_edit_${System.currentTimeMillis()}.jpg"); put(android.provider.MediaStore.Images.Media.MIME_TYPE, "image/jpeg") }
        val nu = c.contentResolver.insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v) ?: return "Não consegui salvar."
        c.contentResolver.openOutputStream(nu)?.use { res.compress(android.graphics.Bitmap.CompressFormat.JPEG, 92, it) }
        go(Intent(Intent.ACTION_VIEW).setDataAndType(nu, "image/*").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        return "Pronto. Salvei uma cópia editada na galeria. A original continua intacta."
    }
    fun local5(l: String, t: String): String? {
        if (Regex("tem infravermelho|infravermelho no celular").containsMatchIn(l))
            return if ((c.getSystemService(Context.CONSUMER_IR_SERVICE) as? android.hardware.ConsumerIrManager)?.hasIrEmitter() == true) "Seu celular tem infravermelho." else "Seu celular não tem emissor de infravermelho, então o telecomando só funciona por Wi-Fi."
        Regex("^(ativa|liga|ativar|desativa|desliga|desativar) (?:o )?(?:controle por )?aceno").find(l)?.let {
            val on = !it.groupValues[1].startsWith("des"); setCfg("aceno", on)
            return if (on) "Aceno ligado. Passe a mão duas vezes rápido sobre a parte de cima da tela para me chamar ou me calar." else "Aceno desligado."
        }
        Regex("^(?:acha|ache|procura|busca|encontra)(?: na galeria)? (?:aquela |a |uma )?(?:foto|imagem) (.+)$").find(l)?.let { return galeria(it.groupValues[1]) }
        if (Regex("foto|imagem").containsMatchIn(l) && Regex("mais clara|clareia|ilumina|escurece|mais escura|contraste|preto e branco|gira|rotaciona|recorta|vertical|quadrad").containsMatchIn(l) &&
            Regex("^(?:deixa|deixe|edita|edite|faz|clareia|escurece|gira|rotaciona|recorta|corta|põe|coloca|tira)").containsMatchIn(l)) return editFoto(l)
        return null
    }
    fun go(i: Intent) { c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    fun acc(f: (JarvisAccess) -> String): String = JarvisAccess.i?.let(f) ?: "Ative o controle de apps nas configurações do Jarvis."
    fun openApp(n0: String): String? {
        val n = n0.trim().lowercase().removePrefix("o ").removePrefix("a ").removePrefix("app ").removePrefix("aplicativo ")
        val pm = c.packageManager
        val ls = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val m = ls.map { it to it.loadLabel(pm).toString().lowercase() }
        val hit = m.firstOrNull { it.second == n } ?: m.firstOrNull { it.second.contains(n) } ?: m.firstOrNull { it.second.length > 2 && n.contains(it.second) }
        if (hit == null) return null
        val li = pm.getLaunchIntentForPackage(hit.first.activityInfo.packageName) ?: return null
        go(li)
        return "Abrindo ${hit.second}."
    }
    fun local(t: String): String? {
        val l = t.lowercase().trim().trimEnd('.', '!', '?')
        if (l.contains("modo conversa")) {
            val on = !Regex("desativ|desliga|sair|encerra").containsMatchIn(l); setCfg("conv", on)
            return if (on) "Modo conversa ativado. Vou continuar ouvindo." else "Modo conversa desativado."
        }
        local2(l)?.let { return it }
        local3(l)?.let { return it }
        local4(l, t)?.let { return it }
        local5(l, t)?.let { return it }
        local6(l, t)?.let { return it }
        local7(l)?.let { return it }
        Regex("^(?:jarvis,? )?(?:lembra|lembre|memorize|anote)(?: que| de)? (.+)").find(l)?.let {
            val j = cfg(); val a = j.optJSONArray("mem") ?: JSONArray()
            a.put(it.groupValues[1]); j.put("mem", a); save(j.toString()); return "Memorizado."
        }
        if (!Regex(" (e|depois|então|aí|pra|para|que) ").containsMatchIn(l))
            Regex("^(?:abr[ae]|abrir|inicia|iniciar|executa)(?: o| a)? (.+)").find(l)?.let { m -> openApp(m.groupValues[1])?.let { return it } }
        if (Regex("^(?:volta|voltar)$").matches(l)) return acc { it.glob(AccessibilityService.GLOBAL_ACTION_BACK) }
        if (Regex("^(?:início|inicio|home|tela inicial)$").matches(l)) return acc { it.glob(AccessibilityService.GLOBAL_ACTION_HOME) }
        if (l == "recentes") return acc { it.glob(AccessibilityService.GLOBAL_ACTION_RECENTS) }
        if (Regex("que horas").containsMatchIn(l)) return "Agora são " + java.text.SimpleDateFormat("HH:mm", Locale("pt", "BR")).format(Date()) + "."
        return null
    }
    fun ask(t: String) {
        sfx("think"); ev("mode", "think")
        Thread {
            if (busy) { cancel = true; var w = 0; while (busy && w < 30) { Thread.sleep(100); w++ } }
            cancel = false; busy = true
            hist.add("user" to t)
            val dr = takeWake()
            var r = try { local(t) ?: agent(t) } catch (e: Exception) { "Falha: ${e.message}" }
            if (!dr.isNullOrBlank()) r = "Bom dia! Enquanto você dormia, tive uma ideia: $dr\n\n$r"
            logLine(t, r)
            busy = false
            hist.add("model" to r)
            while (hist.size > 24) hist.removeAt(0)
            ev("reply", r); if (r != ".") sfx("done")
            if (r != ".") h.postDelayed({ speak(r) }, 250)
        }.start()
    }
}
